﻿using System;
using System.Collections.Generic;
using System.Data;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserLogin : System.Web.UI.Page
{
    #region VariableDeclare
    LoginModule obj = new LoginModule();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            btnUserLogin.Focus();
            if (Session["EmpCode"] != null && Session["Role"].ToString().Equals("Admin"))
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'User ID and password have been authenticated successfully.', 'Success', 'AdminPanel/Dashboard.aspx','1000');", true);
            }
            else if (Session["EmpCode"] != null && Session["Role"].ToString().Equals("User"))
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'User ID and password have been authenticated successfully.', 'Success', 'UserPanel/Dashboard.aspx','1000');", true);
            }
            else
            {
                // Generate a new CSRF token
                ViewState["CSRFToken"] = Guid.NewGuid().ToString();
                hiddenCsrfToken.Value = ViewState["CSRFToken"].ToString();
            }
        }
    }
    #region LoginUser
    protected void btnUserLogin_Click(object sender, EventArgs e)
    {
        if (ViewState["CSRFToken"] != null && ViewState["CSRFToken"].ToString() == hiddenCsrfToken.Value)
        {
            string UserId = string.Empty;
            string UserIdForVerification = string.Empty;
            try
            {
                if (HttpUtility.HtmlEncode(txtUserId.Text.Trim()).Contains("@"))
                {
                    UserId = HttpUtility.HtmlEncode(txtUserId.Text.Trim());
                    string[] UserName = UserId.Split('@');
                    UserIdForVerification = UserName[0];
                }
                else
                {
                    UserId = HttpUtility.HtmlEncode(txtUserId.Text.Trim()) + "@dsgroup.com";
                    UserIdForVerification = HttpUtility.HtmlEncode(txtUserId.Text.Trim());
                }
                bool Isvalid = CheckUserInDomain(UserIdForVerification, txtPassword.Text.Trim());
                if (Isvalid)
                {
                    GetUserDetailsForAutoLogin(UserId);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'User Id And Password is not correct!', 'Error');", true);
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'An unexpected error occurred. Please try again later.', 'Error');", true);
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Oops! It looks like your session has expired or there an issue with the form submission. Please try again. If the problem persists, contact support.', 'Error');", true);
        }
    }
    #endregion
    #region CheckUserInDomain
    protected bool CheckUserInDomain(string userName, string Pwd)
    {
        try
        {
            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, "dsl.com"))
            {
                return pc.ValidateCredentials(userName, Pwd);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetUserDetailsForAutoLogin
    public void GetUserDetailsForAutoLogin(string UserId)
    {
        try
        {
            DataSet ds = obj.GetUserDetailsForAutoLogin("pooja.saboo@dsgroup.com");
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["Title"] = ds.Tables[0].Rows[0]["TITLE"].ToString();
                Session["EmployeeName"] = ds.Tables[0].Rows[0]["Employee_Name"].ToString();
                Session["EmpCode"] = ds.Tables[0].Rows[0]["Emp_Code"].ToString();
                Session["EmpEmail"] = ds.Tables[0].Rows[0]["Email_ID"].ToString();
                Session["DeptCode"] = ds.Tables[0].Rows[0]["Dept_Code"].ToString();
                btnUserLogin.Enabled = false;
                btnUserLogin.Text = "Processing...";

                string email = ds.Tables[0].Rows[0]["email_id"].ToString();
                if (email == "arshad.hussain@dsgroup.com" ||
                    email == "prachi.grover@dsgroup.com" ||
                    email == "balam.singh@dsgroup.com" ||
                    email == "husain.saeed@dsgroup.com" ||
                    email == "chetan.kushwaha@dsgroup.com")
                {
                    Session["Role"] = "Admin";

                    // Check if a return URL exists
                    string returnUrl = Session["ReturnUrl"] as string;
                    if (!string.IsNullOrEmpty(returnUrl))
                    {
                        Session["ReturnUrl"] = null; // Clear the session
                        Response.Redirect(returnUrl); // Redirect to the saved URL
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'User ID and password have been authenticated successfully.', 'Success', 'AdminPanel/Dashboard.aspx','1000');", true);
                    }
                }
                else
                {
                    Session["Role"] = "User";
                    // Check if a return URL exists
                    string returnUrl = Session["ReturnUrl"] as string;
                    if (!string.IsNullOrEmpty(returnUrl))
                    {
                        Session["ReturnUrl"] = null; // Clear the session
                        Response.Redirect(returnUrl); // Redirect to the saved URL
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'User ID and password have been authenticated successfully.', 'Success', 'UserPanel/Dashboard.aspx','1000');", true);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}