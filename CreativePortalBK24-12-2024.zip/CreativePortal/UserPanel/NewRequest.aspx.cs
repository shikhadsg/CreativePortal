﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserPanel_NewRequest : System.Web.UI.Page
{
    #region DeclareVariable 
    JobRequest obj = new JobRequest();
    MailUtility objm = new MailUtility();
    string Url = "https://webportal.dsgroup.com/CREPortal/";
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                txtTargetDate.Attributes["min"] = DateTime.Now.ToString("yyyy-MM-dd");
                txtUserRemarks.Attributes.Add("maxlength", txtUserRemarks.MaxLength.ToString());
                txtMatter.Attributes.Add("maxlength", txtMatter.MaxLength.ToString());
                txtEntryDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
                GetRequestNo();
                GetAssignToUser();
                GetMasterDataList();
                GetRateMasterList();
                if (Request.QueryString["ReqId"] != null)
                {
                    btnNewRequest.Text = "Submit Copy Job Request";
                    btnNewRequest.ToolTip = "Click here to submit copy job request details.";
                    hndReqId.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["ReqId"].ToString()));
                    GetJobRequestDetails();
                }
                else
                {
                    btnNewRequest.Text = "Submit New Job Request";
                    btnNewRequest.ToolTip = "Click here to submit new job request details.";
                }
            }
        }
    }
    #region GetAssignToUser
    private void GetAssignToUser()
    {
        try
        {
            DataSet ds = obj.GetAssignToUser(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlAssignTo.DataSource = ds.Tables[0];
                ddlAssignTo.DataTextField = "Employee_Name";
                ddlAssignTo.DataValueField = "EMAIL_ID";
                ddlAssignTo.DataBind();
                ddlAssignTo.Items.Insert(0, new ListItem("--Select Assign To--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetRequestNo
    private void GetRequestNo()
    {
        try
        {
            DataSet ds = obj.GetRequestNo(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtRequestNo.Text = "CRE-" + ds.Tables[0].Rows[0]["RequestNo"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetRateMasterList
    private void GetRateMasterList()
    {
        try
        {
            DataSet ds = obj.GetRateMasterList(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlHead.DataSource = ds.Tables[0];
                ddlHead.DataTextField = "Head";
                ddlHead.DataValueField = "Head";
                ddlHead.DataBind();
                ddlHead.Items.Insert(0, new ListItem("--Select Head--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetMasterDataList
    private void GetMasterDataList()
    {
        try
        {
            DataSet ds = obj.GetMasterDataList(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlBrand.DataSource = ds.Tables[0];
                ddlBrand.DataTextField = "BRAND_NAME";
                ddlBrand.DataValueField = "BRAND_ID";
                ddlBrand.DataBind();
                ddlBrand.Items.Insert(0, new ListItem("--Select Brand--", ""));
                ddlBrand.Items.Insert(24, new ListItem("Other", "24"));
            }

            if (ds.Tables[1].Rows.Count > 0)
            {
                ddlType.DataSource = ds.Tables[1];
                ddlType.DataTextField = "MEANING";
                ddlType.DataValueField = "LOOKUP_TYPE_ID";
                ddlType.DataBind();
                ddlType.Items.Insert(0, new ListItem("--Select Type--", ""));
            }
            if (ds.Tables[5].Rows.Count > 0)
            {
                ddlMailToUser.DataSource = ds.Tables[5];
                ddlMailToUser.DataTextField = "EMPLOYEE_NAME";
                ddlMailToUser.DataValueField = "Email_Id";
                ddlMailToUser.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetJobRequestDetails
    private void GetJobRequestDetails()
    {
        try
        {
            DataSet ds = obj.GetJobRequestDetails(Session["EmpCode"].ToString(),hndReqId.Value);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlJobRequestType.SelectedValue = ds.Tables[0].Rows[0]["ATT2"].ToString();
                ddlPriority.SelectedValue = ds.Tables[0].Rows[0]["PRIORITY"].ToString();
                ddlBrand.SelectedValue = ds.Tables[0].Rows[0]["BRAND"].ToString();

                DataSet ds1 = obj.GetMasterDataList(Session["EmpCode"].ToString(), ds.Tables[0].Rows[0]["BRAND"].ToString());
                ddlCategory.Items.Clear();
                if (ds1.Tables[2].Rows.Count > 0)
                {
                    ddlCategory.DataSource = ds1.Tables[2];
                    ddlCategory.DataTextField = "BRANDCATEGORY_NAME";
                    ddlCategory.DataValueField = "BRANDCATEGORY_ID";
                    ddlCategory.DataBind();
                }
                ddlCategory.SelectedValue = ds.Tables[0].Rows[0]["CATEGORY"].ToString();
                DataSet ds2 = obj.GetMasterDataList(Session["EmpCode"].ToString(), ds.Tables[0].Rows[0]["CATEGORY"].ToString());
                ddlVarient.Items.Clear();
                if (ds2.Tables[3].Rows.Count > 0)
                {
                    ddlVarient.DataSource = ds2.Tables[3];
                    ddlVarient.DataTextField = "BRANDVARIANT_NAME";
                    ddlVarient.DataValueField = "BRANDVARIANT_ID";
                    ddlVarient.DataBind();
                }
                ddlVarient.SelectedValue = ds.Tables[0].Rows[0]["VARIANT"].ToString();
                txtSKU.Text = ds.Tables[0].Rows[0]["SKU"].ToString();
                ddlType.SelectedValue = ds.Tables[0].Rows[0]["CRE_TYPE"].ToString();

                DataSet ds3 = obj.GetMasterDataList(Session["EmpCode"].ToString(), ds.Tables[0].Rows[0]["CRE_TYPE"].ToString());
                ddlSubType.Items.Clear();
                if (ds3.Tables[4].Rows.Count > 0)
                {
                    ddlSubType.DataSource = ds3.Tables[4];
                    ddlSubType.DataTextField = "DISPLAY_VALUE";
                    ddlSubType.DataValueField = "LOOKUP_CD";
                    ddlSubType.DataBind();
                }
                ddlSubType.SelectedValue = ds.Tables[0].Rows[0]["CRE_SUBTYPE"].ToString();
                txtLanguage.Text = ds.Tables[0].Rows[0]["P_LANGUAGE"].ToString();
                if(ds.Tables[0].Rows[0]["CRE_TYPE_OTHER"].ToString().Equals("-"))
                {
                    txtOtherType.Text = "";
                    txtOtherType.Enabled = false;
                }
                else
                {
                    txtOtherType.Text = ds.Tables[0].Rows[0]["CRE_TYPE_OTHER"].ToString();
                    txtOtherType.Enabled = true;
                }
                if (ds.Tables[0].Rows[0]["FORMAT_OTHER"].ToString().Equals("-"))
                {
                    txtOtherArtworkFormat.Text = "";
                    txtOtherArtworkFormat.Enabled = false;
                }
                else
                {
                    txtOtherArtworkFormat.Text = ds.Tables[0].Rows[0]["FORMAT_OTHER"].ToString();
                    txtOtherArtworkFormat.Enabled = true;
                }

                txtMatter.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["P_SUBSTRATE"].ToString());
                txtUserRemarks.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["USER_REMARK"].ToString());
                txtTargetDate.Text = ds.Tables[0].Rows[0]["TARGET_DATE"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetBrandCategory
    protected void ddlBrand_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlBrand.SelectedValue.Equals("24"))
            {
                txtOtherBrand.Enabled = true;
                rfvOtherBrand.Visible = true;
                txtOtherBrand.Visible = true;
                rfvCategory.Visible = false;
            }
            else
            {
                txtOtherBrand.Text = "";
                txtOtherBrand.Enabled = false;
                rfvOtherBrand.Visible = false;
                txtOtherBrand.Visible = false;
                rfvCategory.Visible = true;
            }
            DataSet ds = obj.GetMasterDataList(Session["EmpCode"].ToString(),ddlBrand.SelectedValue);
            ddlCategory.Items.Clear();
            if (ds.Tables[2].Rows.Count > 0)
            {
                ddlCategory.DataSource = ds.Tables[2];
                ddlCategory.DataTextField = "BRANDCATEGORY_NAME";
                ddlCategory.DataValueField = "BRANDCATEGORY_ID";
                ddlCategory.DataBind();
                ddlCategory.Items.Insert(0, new ListItem("--Select Category--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetVariant
    protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = obj.GetMasterDataList(Session["EmpCode"].ToString(), ddlCategory.SelectedValue);
            ddlVarient.Items.Clear();
            if (ds.Tables[3].Rows.Count > 0)
            {
                ddlVarient.DataSource = ds.Tables[3];
                ddlVarient.DataTextField = "BRANDVARIANT_NAME";
                ddlVarient.DataValueField = "BRANDVARIANT_ID";
                ddlVarient.DataBind();
                ddlVarient.Items.Insert(0, new ListItem("--Select Varient--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetSubType
    protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = obj.GetMasterDataList(Session["EmpCode"].ToString(), ddlType.SelectedValue);
            ddlSubType.Items.Clear();
            if (ds.Tables[4].Rows.Count > 0)
            {
                ddlSubType.DataSource = ds.Tables[4];
                ddlSubType.DataTextField = "DISPLAY_VALUE";
                ddlSubType.DataValueField = "LOOKUP_CD";
                ddlSubType.DataBind();
                ddlSubType.Items.Insert(0, new ListItem("--Select Sub Type--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region Enable/DisableOtherType
    protected void ddlSubType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlSubType.SelectedItem.Text.Contains("Other"))
        {
            txtOtherType.Enabled = true;
            rfvOtherType.Visible = true;
        }
        else
        {
            txtOtherType.Text = "";
            txtOtherType.Enabled = false;
            rfvOtherType.Visible = false;
        }
    }
    #endregion
    #region CallEnableDisableOtherArtworkFormatBox
    protected void chkFormat_SelectedIndexChanged(object sender, EventArgs e)
    {
        int count = 0;
        try
        {
            List<ListItem> selectedItems = new List<ListItem>();

            // Count selected items and store references to the selected ones
            foreach (ListItem item in chkFormat.Items)
            {
                if (item.Selected)
                {
                    count++;
                    selectedItems.Add(item);
                }
            }

            if (count <= 2)
            {
                EnableDisableOtherArtworkFormatBox();
            }
            else
            {
                // Uncheck the third selected checkbox
                selectedItems[2].Selected = false;

                // Show an error message
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'You can select a maximum of 2 Artwork Formats.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region Enable/DisableOtherArtworkFormatBox
    private void EnableDisableOtherArtworkFormatBox()
    {
        try
        {
            if (chkFormat.SelectedValue == "Other")
            {
                txtOtherArtworkFormat.Enabled = true;
                rfvOtherArtworkFormat.Visible = true;

                // Disable the second option initially
                chkFormat.Items[0].Enabled = false;
                chkFormat.Items[1].Enabled = false;
                chkFormat.Items[2].Enabled = false;
                chkFormat.Items[3].Enabled = false;
                chkFormat.Items[4].Enabled = false;
                chkFormat.Items[5].Enabled = false;
                chkFormat.Items[6].Enabled = true;
            }
            else if (chkFormat.SelectedValue.Equals("PDF") || chkFormat.SelectedValue.Equals("AI") || chkFormat.SelectedValue.Equals("CDR") || chkFormat.SelectedValue.Equals("PSD") || chkFormat.SelectedValue.Equals("JPG") || chkFormat.SelectedValue.Equals("PNG"))
            {
                txtOtherArtworkFormat.Enabled = false;
                txtOtherArtworkFormat.Text = "";
                rfvOtherArtworkFormat.Visible = false;
                chkFormat.Items[0].Enabled = true;
                chkFormat.Items[1].Enabled = true;
                chkFormat.Items[2].Enabled = true;
                chkFormat.Items[3].Enabled = true;
                chkFormat.Items[4].Enabled = true;
                chkFormat.Items[5].Enabled = true;
                chkFormat.Items[6].Enabled = false;
            }
            else
            {
                txtOtherArtworkFormat.Enabled = false;
                txtOtherArtworkFormat.Text = "";
                rfvOtherArtworkFormat.Visible = false;
                chkFormat.Items[0].Enabled = true;
                chkFormat.Items[1].Enabled = true;
                chkFormat.Items[2].Enabled = true;
                chkFormat.Items[3].Enabled = true;
                chkFormat.Items[4].Enabled = true;
                chkFormat.Items[5].Enabled = true;
                chkFormat.Items[6].Enabled = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ResetPage
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            hndReqId.Value = "";
            Response.Redirect("NewRequest.aspx");
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SaveJobRequest
    protected void btnNewRequest_Click(object sender, EventArgs e)
    {
        int success = 0;
        int MailMsg = 0;
        int count = 0;
        string RequestNo = string.Empty;
        string ArtworkFormat = string.Empty;
        string currdate = Convert.ToDateTime(DateTime.Now).ToString("dd/MM/yyyy HH:mm:ss");
        try
        {
            DataSet ds = obj.GetRequestNo(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                RequestNo = "CRE-" + ds.Tables[0].Rows[0]["RequestNo"].ToString();

                List<String> checkedList = new List<string>();
                foreach (ListItem item in chkFormat.Items)
                {
                    if (item.Selected)
                    {
                        count++;
                        checkedList.Add(item.Text);

                        ArtworkFormat = String.Join(",", checkedList);
                    }
                }
                if (count > 0)
                {
                    success = obj.AddUpdateJobRequest(Session["EmpCode"].ToString(), RequestNo,HttpUtility.HtmlEncode(txtEntryDate.Text.Trim()), ddlJobRequestType.SelectedValue, 
                        ddlPriority.SelectedValue,ddlBrand.SelectedValue, HttpUtility.HtmlEncode(txtOtherBrand.Text.Trim()),ddlCategory.SelectedValue,ddlVarient.SelectedValue,
                        HttpUtility.HtmlEncode(txtSKU.Text.Trim()),ddlType.SelectedValue,ddlSubType.SelectedValue, HttpUtility.HtmlEncode(txtOtherType.Text.Trim()),
                        HttpUtility.HtmlEncode(txtLanguage.Text.Trim()), HttpUtility.HtmlEncode(txtTargetDate.Text.Trim()),ArtworkFormat, 
                        HttpUtility.HtmlEncode(txtSFTPFilePath.Text.Trim()), HttpUtility.HtmlEncode(txtOtherArtworkFormat.Text.Trim()), HttpUtility.HtmlEncode(txtMatter.Text.Trim()),
                        HttpUtility.HtmlEncode(txtUserRemarks.Text.Trim()), ddlAssignTo.SelectedValue, ddlAssignTo.SelectedItem.Text, currdate,hlViewAttchedFile.Text);
                    if(success > 0)
                    {
                        MailMsg = obj.SaveMailToCc(Session["EmpCode"].ToString(), RequestNo, ddlAssignTo.SelectedValue, hndSelectedUserMailCc.Value);
                        if(MailMsg > 0)
                        {
                            DataSet dsMaxId = obj.GetMaxRequestId(Session["EmpCode"].ToString());
                            if (dsMaxId.Tables[0].Rows.Count > 0)
                            {
                                string RequestId = dsMaxId.Tables[0].Rows[0]["MaxRequestId"].ToString();
                                string Subject = "Creative Design Job Request Document No. " + RequestNo;
                                string Body = "You have received a new Creative Design job request. Please take a moment to review the details and proceed with the necessary actions at your earliest convenience.";
                                Url = Url + "AdminPanel/ViewJobRequest.aspx?ReqId=" + CommonUtility.Encryption(RequestId);
                                objm.SendMailForJobRequest(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(), ddlAssignTo.SelectedValue, ddlAssignTo.SelectedItem.Text,hndSelectedUserMailCc.Value, Subject, Body, "", Url);
                            }
                        }
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'Job request is successfully submitted.', 'Success', 'ListOfJobRequest.aspx','1000');", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Job request is not submitted. Please try again later.', 'Error');", true);
                    }
                }
                else
                {
                    chkFormat.Focus();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Please select atleast one Artwork Format.', 'Error');", true);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ShowSelectedMailToUser
    protected void ddlMailToUser_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            List<String> checkedList = new List<string>();
            List<String> SelectedUserMailCc = new List<string>();
            foreach (ListItem item in ddlMailToUser.Items)
            {
                if (item.Selected)
                {
                    checkedList.Add(item.Text);
                    SelectedUserMailCc.Add(item.Value);

                    lblSelectedUserMailCc.Text = String.Join(", ", checkedList);
                    hndSelectedUserMailCc.Value = String.Join(", ", SelectedUserMailCc);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetBasis
    protected void ddlHead_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = obj.GetRateMasterList(Session["EmpCode"].ToString(),ddlHead.SelectedValue);
            if (ds.Tables[1].Rows.Count > 0)
            {
                ddlBasis.DataSource = ds.Tables[1];
                ddlBasis.DataTextField = "Basis";
                ddlBasis.DataValueField = "Basis";
                ddlBasis.DataBind();
                ddlBasis.Items.Insert(0, new ListItem("--Select Basis--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetSubHead
    protected void ddlBasis_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = obj.GetRateMasterList(Session["EmpCode"].ToString(), ddlBasis.SelectedValue);
            if (ds.Tables[2].Rows.Count > 0)
            {
                ddlSubHead.DataSource = ds.Tables[2];
                ddlSubHead.DataTextField = "SUB_HEAD";
                ddlSubHead.DataValueField = "SUB_HEAD";
                ddlSubHead.DataBind();
                ddlSubHead.Items.Insert(0, new ListItem("--Select Sub Head--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetRate
    protected void ddlSubHead_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = obj.GetRateMasterList(Session["EmpCode"].ToString(), ddlSubHead.SelectedValue);
            if (ds.Tables[3].Rows.Count > 0)
            {
                ddlRate.DataSource = ds.Tables[3];
                ddlRate.DataTextField = "Rate";
                ddlRate.DataValueField = "Rate";
                ddlRate.DataBind();
                ddlRate.Items.Insert(0, new ListItem("--Select Rate--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region UploadAttachedFile
    protected void btnUploadAttachedFile_Click(object sender, EventArgs e)
    {
        string FileName = string.Empty;
        string FolderPath = string.Empty;
        try
        {
            if (flupload.HasFile)
            {
                string FileExt = Path.GetExtension(flupload.FileName);
                decimal FileSize = Math.Round(((decimal)flupload.PostedFile.ContentLength / (decimal)1024), 2);
                if (FileExt.Equals(".jpeg") || FileExt.Equals(".jpg") || FileExt.Equals(".png") || FileExt.Equals(".pdf") || FileExt.Equals(".zip"))
                {
                    if (FileSize <= 5000)
                    {
                        FolderPath = Server.MapPath(WebConfigurationManager.AppSettings["JobRequestFile"]);
                        FileName = Path.GetFileNameWithoutExtension(flupload.PostedFile.FileName) + "_" + DateTime.Now.ToString("yyyy-dd-M--HH-mm-ss") + FileExt;
                        if (!Directory.Exists(FolderPath))
                        {
                            Directory.CreateDirectory(FolderPath);
                        }
                        if (FileName.Length > 5)
                        {
                            flupload.PostedFile.SaveAs(FolderPath + "\\" + FileName);
                            hlViewAttchedFile.NavigateUrl = "../Docs/" + FileName;
                            hlViewAttchedFile.ForeColor = Color.Green; ;
                            hlViewAttchedFile.Enabled = true;
                            hlViewAttchedFile.Text = FileName;
                            hlViewAttchedFile.Target = "_blank";
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'File is successfully uploaded.', 'Success');", true);
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'The file size exceeds 5 MB. Kindly resubmit the document with a file size not exceeding 5 MB', 'Error');", true);
                        return;
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'we need you to upload documents in either zip,pdf,jpeg,jpg and png file formats only', 'Error');", true);
                    return;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}