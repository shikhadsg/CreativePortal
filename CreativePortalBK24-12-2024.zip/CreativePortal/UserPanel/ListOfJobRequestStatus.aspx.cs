﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserPanel_ListOfJobRequestStatus : System.Web.UI.Page
{
    #region DeclareVariable 
    JobRequest obj = new JobRequest();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmpCode"] != null)
        {
            if (!IsPostBack)
            {
                txtFeedback.Attributes.Add("maxlength", txtFeedback.MaxLength.ToString());
                if (Request.QueryString["StatusId"] != null)
                {
                    hndStatusId.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["StatusId"].ToString()));
                    GetJobRequestList();
                }
            }
        }
    }
    #region GetJobRequestList
    protected void GetJobRequestList()
    {
        try
        {
            DataSet ds = obj.GetJobRequestList(Session["EmpCode"].ToString(), "" ,hndStatusId.Value);
            if (ds.Tables[1].Rows.Count > 0)
            {
                btnExport.Visible = true;
                gvData.DataSource = ds.Tables[1];
                gvData.DataBind();
                if (hndStatusId.Value.Equals("F"))
                {
                    gvData.Columns[0].Visible = true;
                }
            }
            else
            {
                btnExport.Visible = false;
                gvData.DataSource = ds.Tables[1];
                gvData.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region PageChangeCode
    protected void gvData_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvData.PageIndex = e.NewPageIndex;
            GetJobRequestList();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportGridDataToExcel
    protected void ExportGridDataToExcel()
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=CreativeBriefFormatReport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";

            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                // To Export all pages.
                gvData.AllowPaging = false;
                this.GetJobRequestList();
                // This is to ensure that the gridview is formatted correctly in Excel
                gvData.HeaderRow.BackColor = Color.Green;
                gvData.HeaderRow.ForeColor = Color.White;
                gvData.Columns[0].Visible = false;
                gvData.Columns[1].Visible = false;
                gvData.Columns[2].Visible = false;

                foreach (TableCell cell in gvData.HeaderRow.Cells)
                {
                    cell.BackColor = gvData.HeaderStyle.BackColor;
                    cell.Font.Size = FontUnit.Point(12);
                }

                foreach (GridViewRow row in gvData.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = Color.White;
                            cell.ForeColor = Color.Black;
                            cell.Font.Size = FontUnit.Point(10);
                        }
                        else
                        {
                            cell.BackColor = Color.White;
                            cell.ForeColor = Color.Black;
                            cell.Font.Size = FontUnit.Point(10);
                        }
                        cell.CssClass = "textmode";
                    }
                }

                gvData.RenderControl(hw);

                // Style to format numbers to string.
                string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        catch (OracleException ex)
        {
            throw ex;
        }
    }
    #endregion
    #region VerifyRenderingInServerForm
    public override void VerifyRenderingInServerForm(Control control)
    {
        /*Tell the compiler that the control is rendered
         * explicitly by overriding the VerifyRenderingInServerForm event.*/
    }
    #endregion
    #region ExportDataToExcel
    protected void btnExcel_Click(object sender, EventArgs e)
    {
        try
        {
            ExportGridDataToExcel();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region OpenPopupbox
    protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if(e.CommandName.Equals("AddFeedback"))
            {
                hndCfdRecId.Value = e.CommandArgument.ToString();
                ActionNotificationBox.Show();
            }
        }
        catch (OracleException ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SaveFeedback
    protected void btnSaveFeedback_Click(object sender, EventArgs e)
    {
        int success = 0;
        try
        {
            success = obj.AddFeedback(Session["EmpCode"].ToString(),hndCfdRecId.Value,HttpUtility.HtmlEncode(txtFeedback.Text.Trim()),ddlRating.SelectedValue);
            if (success > 0)
            {
                GetJobRequestList();
                txtFeedback.Text = "";
                ddlRating.SelectedValue = "";
                ActionNotificationBox.Hide();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Feedback is successfully saved.', 'Success');", true);
            }
            else
            {
                ActionNotificationBox.Show();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Feedback is not saved. Please try again later.', 'Error');", true);
            }
        }
        catch (OracleException ex)
        {
            throw ex;
        }
    }
    #endregion
}