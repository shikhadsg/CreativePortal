﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserPanel_Dashboard : System.Web.UI.Page
{
    #region VariableDeclare
    JobRequest obj = new JobRequest();
    protected string RequestSubmitted;
    protected string RequestProcessed;
    protected string DesignReceive;
    protected string CompleteRequest;
    protected string RejectRequest;
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmpCode"] != null)
        {
            if (!IsPostBack)
            {
                GetUserDashboardData();
            }
        }
    }
    #region GetUserDashboardData
    private void GetUserDashboardData()
    {
        try
        {
            DataSet ds = obj.GetUserDashboardData(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                RequestSubmitted = ds.Tables[0].Rows[0]["TotalRequest"].ToString();
                RequestProcessed = ds.Tables[0].Rows[1]["TotalRequest"].ToString();
                CompleteRequest = ds.Tables[0].Rows[2]["TotalRequest"].ToString();
                RejectRequest = ds.Tables[0].Rows[3]["TotalRequest"].ToString();
                DesignReceive = ds.Tables[0].Rows[4]["TotalRequest"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}