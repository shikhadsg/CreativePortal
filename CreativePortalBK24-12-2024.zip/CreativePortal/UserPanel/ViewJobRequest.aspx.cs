﻿using System;
using System.Data;
using System.Web;
using System.Drawing;
using System.IO;
using System.Web.Configuration;
using System.Web.UI;


public partial class UserPanel_ViewJobRequest : System.Web.UI.Page
{
    #region DeclareVariable 
    JobRequest obj = new JobRequest();
    MailUtility objm = new MailUtility();
    string Url = "https://webportal.dsgroup.com/CREPortal/";
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmpCode"] != null)
        {
            if (!IsPostBack)
            {
                txtRemark.Attributes.Add("maxlength", txtRemark.MaxLength.ToString());
                if (Request.QueryString["ReqId"] != null)
                {
                    hndReqId.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["ReqId"].ToString()));
                    GetJobRequestDetails();
                }
            }
        }
    }
    #region GetJobRequestDetails
    private void GetJobRequestDetails()
    {
        try
        {
            DataSet ds = obj.GetJobRequestDetails(Session["EmpCode"].ToString(), hndReqId.Value);
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (ds.Tables[0].Rows[0]["FORMAT_STATUS"].ToString().Equals("F") || ds.Tables[0].Rows[0]["FORMAT_STATUS"].ToString().Equals("U"))
                {
                    btnSaveRemarks.Visible = false;
                    UserRemarks.Visible = false;
                }
                if (ds.Tables[0].Rows[0]["FORMAT_STATUS"].ToString().Equals("S") && ds.Tables[0].Rows[0]["CREATED_BY"].ToString().Equals(Session["EmpCode"].ToString()))
                {
                    btnDesignAccepted.Visible = true;
                }
                lblRequestNo.Text = ds.Tables[0].Rows[0]["REQUEST_NO"].ToString();
                lblJobRequestType.Text = ds.Tables[0].Rows[0]["ATT2"].ToString();
                lblPriority.Text = ds.Tables[0].Rows[0]["PRIORITYNAME"].ToString();
                lblBrand.Text = ds.Tables[0].Rows[0]["BRAND_NAME"].ToString();
                lblCategory.Text = ds.Tables[0].Rows[0]["BRANDCATEGORY_NAME"].ToString();
                lblVarient.Text = ds.Tables[0].Rows[0]["BRANDVARIANT_NAME"].ToString();
                lblSKU.Text = ds.Tables[0].Rows[0]["SKU"].ToString();
                txtOtherBrand.Text = ds.Tables[0].Rows[0]["BRAND_OTHER"].ToString();
                lblType.Text = ds.Tables[0].Rows[0]["TYPENAME"].ToString();
                lblSubType.Text = ds.Tables[0].Rows[0]["CRE_SUBTYPE"].ToString();
                lblOtherType.Text = ds.Tables[0].Rows[0]["CRE_TYPE_OTHER"].ToString();
                lblLANGUAGE.Text = ds.Tables[0].Rows[0]["P_LANGUAGE"].ToString();
                lblEntryDt.Text = ds.Tables[0].Rows[0]["ENTRY_DATE"].ToString();
                lblTargetDate.Text = ds.Tables[0].Rows[0]["TARGET_DATE"].ToString();
                lblMatter.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["P_SUBSTRATE"].ToString());
                lblUserRemarks.Text = HttpUtility.HtmlDecode(ds.Tables[0].Rows[0]["USER_REMARK"].ToString());
                lblArtworkFormat.Text = ds.Tables[0].Rows[0]["P_FORMAT"].ToString();
                lblOtherArtworkFormat.Text = ds.Tables[0].Rows[0]["FORMAT_OTHER"].ToString();
                lblAssignTo.Text = ds.Tables[0].Rows[0]["ASSIGN_TO"].ToString();
                hndAssignToEmail.Value = "ASSIGN_TO_EMAIL";
                hndCreaterName.Value = ds.Tables[0].Rows[0]["Employee_Name"].ToString();
                hndCreaterEmail.Value = ds.Tables[0].Rows[0]["Creater_Email"].ToString();

                //lblHead.Text = ds.Tables[0].Rows[0]["Head"].ToString();
                //lblBasis.Text = ds.Tables[0].Rows[0]["Basis"].ToString();
                //lblSubHead.Text = ds.Tables[0].Rows[0]["Sub_Head"].ToString();
                //lblRate.Text = ds.Tables[0].Rows[0]["Rate"].ToString();

                if (ds.Tables[0].Rows[0]["SFTP_PATH"].ToString().Equals("Na"))
                {
                    hlSFTPFilePath.Enabled = false;
                    hlSFTPFilePath.ForeColor = Color.Red;
                    hlSFTPFilePath.ToolTip = "Attached file not available.";
                    hlSFTPFilePath.NavigateUrl = "#";
                    hlSFTPFilePath.Text = "NA";
                }
                else
                {
                    hlSFTPFilePath.Enabled = true;
                    hlSFTPFilePath.ForeColor = Color.Green;
                    hlSFTPFilePath.ToolTip = "Click here to view attached file.";
                    hlSFTPFilePath.NavigateUrl = ds.Tables[0].Rows[0]["SFTP_PATH"].ToString();
                    hlSFTPFilePath.Text = ds.Tables[0].Rows[0]["SFTP_PATH"].ToString();
                    hlSFTPFilePath.Target = "_blank";
                }
                lblNewDeadline.Text = ds.Tables[0].Rows[0]["NEW_TIMELINE"].ToString();

                if (ds.Tables[0].Rows[0]["MEDIA_FILE_PATH"].ToString().Equals("Na"))
                {
                    hlAttachedFile.Enabled = false;
                    hlAttachedFile.ForeColor = Color.Red;
                    hlAttachedFile.ToolTip = "Attached file not available.";
                    hlAttachedFile.NavigateUrl = "#";
                    hlAttachedFile.Text = "NA";
                }
                else
                {
                    hlAttachedFile.Enabled = true;
                    hlAttachedFile.ForeColor = Color.Green;
                    hlAttachedFile.ToolTip = "Click here to view attached file.";
                    hlAttachedFile.NavigateUrl = "../Docs/" + ds.Tables[0].Rows[0]["MEDIA_FILE_PATH"].ToString();
                    hlAttachedFile.Text = ds.Tables[0].Rows[0]["MEDIA_FILE_PATH"].ToString();
                    hlAttachedFile.Target = "_blank";
                }
                lblRateCard.Text = ds.Tables[0].Rows[0]["Rate_Card"].ToString();
                lblPageRate.Text = ds.Tables[0].Rows[0]["Page_Rate"].ToString();
                if (ds.Tables[0].Rows[0]["FINALDESIGNPATH"].ToString().Equals("Na"))
                {
                    hlDesignFinalPath.Enabled = false;
                    hlDesignFinalPath.ForeColor = Color.Red;
                    hlDesignFinalPath.ToolTip = "Attached file not available.";
                    hlDesignFinalPath.NavigateUrl = "#";
                    hlDesignFinalPath.Text = "NA";
                }
                else
                {
                    hlDesignFinalPath.Enabled = true;
                    hlDesignFinalPath.ForeColor = Color.Green;
                    hlDesignFinalPath.ToolTip = "Click here to view attached file.";
                    hlDesignFinalPath.NavigateUrl = ds.Tables[0].Rows[0]["FINALDESIGNPATH"].ToString();
                    hlDesignFinalPath.Text = ds.Tables[0].Rows[0]["FINALDESIGNPATH"].ToString();
                    hlDesignFinalPath.Target = "_blank";
                }
                lblJobRequestStatus.Text = ds.Tables[0].Rows[0]["FORMAT_STATUS_DESC"].ToString();
                DataSet dsToCcMail = obj.GetToCcMail(Session["EmpCode"].ToString(), ds.Tables[0].Rows[0]["REQUEST_NO"].ToString());
                if (dsToCcMail.Tables[0].Rows.Count > 0)
                {
                    lblToMail.Text = dsToCcMail.Tables[0].Rows[0]["Mail_To"].ToString();
                    lblCcMail.Text = dsToCcMail.Tables[0].Rows[0]["Mail_Cc"].ToString();
                }
            }
            if (ds.Tables[1].Rows.Count > 0)
            {
                grdFileList.DataSource = ds.Tables[1];
                grdFileList.DataBind();
            }
            else
            {
                grdFileList.DataSource = ds.Tables[1];
                grdFileList.DataBind();
            }
            if (ds.Tables[2].Rows.Count > 0)
            {
                grdRemarks.DataSource = ds.Tables[2];
                grdRemarks.DataBind();
            }
            else
            {
                grdRemarks.DataSource = ds.Tables[2];
                grdRemarks.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SaveRemarksAndFile
    protected void btnSaveRemarks_Click(object sender, EventArgs e)
    {
        int success = 0;
        string FileName = string.Empty;
        string FolderPath = string.Empty;
        string currdate = Convert.ToDateTime(DateTime.Now).ToString("dd/MM/yyyy HH:mm:ss");
        try
        {
            if (flupload.HasFile)
            {
                string FileExt = Path.GetExtension(flupload.FileName);
                decimal FileSize = Math.Round(((decimal)flupload.PostedFile.ContentLength / (decimal)1024), 2);
                if (FileExt.Equals(".jpeg") || FileExt.Equals(".jpg") || FileExt.Equals(".png") || FileExt.Equals(".pdf"))
                {
                    if (FileSize <= 10000)
                    {
                        FolderPath = Server.MapPath(WebConfigurationManager.AppSettings["JobRequestFile"]);
                        FileName = Path.GetFileNameWithoutExtension(flupload.PostedFile.FileName) + "_" + DateTime.Now.ToString("yyyy-dd-M--HH-mm-ss") + FileExt;
                        if (!Directory.Exists(FolderPath))
                        {
                            Directory.CreateDirectory(FolderPath);
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'The file size exceeds 10 MB. Kindly resubmit the document with a file size not exceeding 5 MB', 'Error');", true);
                        return;
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'we need you to upload documents in either pdf,jpeg,jpg and png file formats only', 'Error');", true);
                    return;
                }
            }
            success = obj.SaveRemarksAndFile(Session["EmpCode"].ToString(), hndReqId.Value, lblRequestNo.Text, HttpUtility.HtmlEncode(txtRemark.Text.Trim()), FileName, currdate);
            if (success > 0)
            {
                if (FileName.Length > 5)
                {
                    flupload.PostedFile.SaveAs(FolderPath + "\\" + FileName);
                }
                string Subject = "Remarks/Comments for Document No. " + lblRequestNo.Text;
                string Body = "You have received the following remarks/comments regarding Document No. " + lblRequestNo.Text;
                Url = Url + "AdminPanel/ViewJobRequest.aspx?ReqId=" + CommonUtility.Encryption(hndReqId.Value);
                objm.SendMailForAction(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(), hndAssignToEmail.Value, lblAssignTo.Text, Subject, Body, txtRemark.Text.Trim(), Url);
                txtRemark.Text = "";
                GetJobRequestDetails();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Remark is successfully added.', 'Success');", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Remark is not added. Please try again later.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region DesignAccept
    protected void btnDesignAccepted_Click(object sender, EventArgs e)
    {
        int success = 0;
        string currdate = Convert.ToDateTime(DateTime.Now).ToString("dd/MM/yyyy HH:mm:ss");
        string Remark = "Job Request Creative Design accepted. " + HttpUtility.HtmlEncode(txtRemark.Text.Trim());
        try
        {
            success = obj.DesignAccept(Session["EmpCode"].ToString(), hndReqId.Value, "F", Remark, "Design Final", currdate, lblRequestNo.Text);
            if (success > 0)
            {
                string Subject = "Creative Design Job Request Document No. " + lblRequestNo.Text;
                string Body = "We’re pleased to inform you that your request for a Creative Design job has been accepted by " + Session["Title"].ToString() + " " + Session["EmployeeName"].ToString() + ". Please take a moment to review the details of the request at your earliest convenience.";
                Url = Url + "AdminPanel/ViewJobRequest.aspx?ReqId=" + CommonUtility.Encryption(hndReqId.Value);
                if (!string.IsNullOrEmpty(hndCreaterEmail.Value))
                {
                    objm.SendMailForAction(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(), hndCreaterEmail.Value, hndCreaterName.Value, Subject, Body, "", Url);
                }
                GetJobRequestDetails();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect",
                    "showToastAndRedirect('success', 'Job Request Creative Design is accepted successfully.', 'Success', 'Dashboard.aspx', '1000');", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Job Request Creative Design is  not accepted. Please try again later.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}