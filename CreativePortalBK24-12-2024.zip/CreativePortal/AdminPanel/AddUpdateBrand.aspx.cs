﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Oracle.ManagedDataAccess.Client;

public partial class PolicyRequest_AddUpdateBrand : System.Web.UI.Page
{
    #region DeclareVariable 
    CreativeClass obj = new CreativeClass();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmpCode"] != null)
        {
            if (!IsPostBack)
            {
                GetBrandList();
            }
        }
    }
    #region GetBrandList
    protected void GetBrandList()
    {
        try
        {
            DataSet ds = obj.GetBrandList(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                GrdBrandList.DataSource = ds.Tables[0];
                GrdBrandList.DataBind();
            }
            else
            {
                GrdBrandList.DataSource = ds.Tables[0];
                GrdBrandList.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFormdata
    private void ClearFormdata()
    {
        try
        {
            hndBRAND_ID.Value = "";
            txtBrand.Text = "";
            ddlStatus.SelectedValue = "21";
            btnSaveBrandList.Text = "Save Brand";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region EditBrandRecord
    protected void GrdBrandList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("EditBrandList"))
            {
                hndBRAND_ID.Value = e.CommandArgument.ToString();
                DataSet ds = obj.GetBrandList(Session["EmpCode"].ToString(),hndBRAND_ID.Value);
                if (ds.Tables[1].Rows.Count > 0)
                {
                    txtBrand.Text = ds.Tables[1].Rows[0]["BRAND_NAME"].ToString();
                    ddlStatus.SelectedValue = ds.Tables[1].Rows[0]["StatusId"].ToString();
                    btnSaveBrandList.Text = "Update Brand";
                    btnSaveBrandList.Focus();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ResetPageData
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            ClearFormdata();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SaveUpdateBrand
    protected void btnSaveBrandList_Click(object sender, EventArgs e)
    {
        int success = 0;
        string currdate = Convert.ToDateTime(DateTime.Now).ToString("dd/MM/yyyy HH:mm:ss");
        try
        {
            success = obj.AddUpdateBrand(Session["EmpCode"].ToString(),hndBRAND_ID.Value,HttpUtility.HtmlEncode(txtBrand.Text.Trim()), ddlStatus.SelectedValue, currdate);
            if (success > 0)
            {
                GetBrandList();
                if (hndBRAND_ID.Value.Equals(""))
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Brand is successfully added.', 'Success');", true);
                }
                else if (hndBRAND_ID.Value != "")
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Brand is successfully updated.', 'Success');", true);
                }
                ClearFormdata();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Brand is not added. Please try again later.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}