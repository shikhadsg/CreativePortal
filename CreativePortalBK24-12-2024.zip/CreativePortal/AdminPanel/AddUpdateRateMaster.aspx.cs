﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPanel_AddUpdateRateMaster : System.Web.UI.Page
{
    #region DeclareVariable 
    CreativeClass obj = new CreativeClass();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmpCode"] != null)
        {
            if (!IsPostBack)
            {
                GetRateMasterList();
            }
        }
    }
    #region GetRateMasterList
    protected void GetRateMasterList()
    {
        try
        {
            DataSet ds = obj.GetRateMasterList(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                GrdRateMasterList.DataSource = ds;
                GrdRateMasterList.DataBind();
            }
            else
            {
                GrdRateMasterList.DataSource = ds.Tables[0];
                GrdRateMasterList.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region UpdateRateList
    protected void GrdRateMasterList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("EditRateList"))
            {
                hndRateId.Value = e.CommandArgument.ToString();
                DataSet ds = obj.GetRateMasterList(Session["EmpCode"].ToString(), hndRateId.Value);
                if (ds.Tables[1].Rows.Count > 0)
                {
                    txtHead.Text = ds.Tables[1].Rows[0]["Head"].ToString();
                    txtBasis.Text = ds.Tables[1].Rows[0]["Basis"].ToString();
                    txtSubHead.Text = ds.Tables[1].Rows[0]["Sub_Head"].ToString();
                    txtRate.Text = ds.Tables[1].Rows[0]["Rate"].ToString();
                    ddlStatus.SelectedValue = ds.Tables[1].Rows[0]["StatusId"].ToString();
                    btnSaveRate.Text = "Update Rate";
                    btnSaveRate.Focus();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFormdata
    private void ClearFormdata()
    {
        try
        {
            hndRateId.Value = "";
            txtHead.Text = "";
            txtBasis.Text = "";
            txtSubHead.Text = "";
            txtRate.Text = "";
            ddlStatus.SelectedValue = "A";
            btnSaveRate.Text = "Save Rate";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region RestPageControll
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            ClearFormdata();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SaveRate
    protected void btnSaveRate_Click(object sender, EventArgs e)
    {
        int success = 0;
        try
        {
            success = obj.AddUpdateRateMaster(Session["EmpCode"].ToString(), hndRateId.Value, HttpUtility.HtmlEncode(txtHead.Text.Trim()), HttpUtility.HtmlEncode(txtBasis.Text.Trim()),
                HttpUtility.HtmlEncode(txtSubHead.Text.Trim()), HttpUtility.HtmlEncode(txtRate.Text.Trim()), ddlStatus.SelectedValue);
            if (success > 0)
            {
                GetRateMasterList();
                if (hndRateId.Value.Equals(""))
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Rate is successfully added.', 'Success');", true);
                }
                else if (hndRateId.Value != "")
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Rate is successfully updated.', 'Success');", true);
                }
                ClearFormdata();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Rate is not added. Please try again later.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}