﻿using System;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.UI;
using System.Web;



public partial class PolicyRequest_AddUpdateCategory : System.Web.UI.Page
{
    #region DeclareVariable 
    CreativeClass obj = new CreativeClass();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmpCode"] != null)
        {
            if (!IsPostBack)
            {
                GetBrandList();
                GetCategoryList();
            }
        }
    }
    #region GetMasterDataList
    private void GetBrandList()
    {
        try
        {
            DataSet ds = obj.GetBrandList(Session["EmpCode"].ToString());
            if (ds.Tables[2].Rows.Count > 0)
            {
                ddlBrand.DataSource = ds.Tables[2];
                ddlBrand.DataTextField = "BRAND_NAME";
                ddlBrand.DataValueField = "BRAND_ID";
                ddlBrand.DataBind();
                ddlBrand.Items.Insert(0, new ListItem("--Select Brand--", ""));
                ddlBrand.Items.Insert(24, new ListItem("Other", "24"));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetBrandList
    protected void GetCategoryList()
    {
        try
        {
            DataSet ds = obj.GetCategoryList(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                GrdCategoryList.DataSource = ds;
                GrdCategoryList.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region EditCategoryRecord
    protected void GrdCategoryList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("EditCategoryList"))
            {
                hndBRANDCATEGORY_ID.Value = e.CommandArgument.ToString();
                DataSet ds = obj.GetCategoryList(Session["EmpCode"].ToString(), hndBRANDCATEGORY_ID.Value);
                if (ds.Tables[1].Rows.Count > 0)
                {
                    txtCategory.Text = ds.Tables[1].Rows[0]["BRANDCATEGORY_NAME"].ToString();
                    ddlBrand.SelectedValue = ds.Tables[1].Rows[0]["BRAND_ID"].ToString();
                    ddlStatus.SelectedValue = ds.Tables[1].Rows[0]["STATUS_ID"].ToString();
                    btnSaveCategoryList.Text = "Update Cateogy";
                    btnSaveCategoryList.Focus();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SaveUpdateCategory
    protected void btnSaveCategoryList_Click(object sender, EventArgs e)
    {
        int success = 0;
        string currdate = Convert.ToDateTime(DateTime.Now).ToString("dd/MM/yyyy HH:mm:ss");
        try
        {
            success = obj.AddUpdateCategory(Session["EmpCode"].ToString(), hndBRANDCATEGORY_ID.Value, ddlBrand.SelectedValue,HttpUtility.HtmlEncode(txtCategory.Text.Trim()), ddlStatus.SelectedValue, currdate);
            if (success > 0)
            {
                GetCategoryList();
                if (hndBRANDCATEGORY_ID.Value.Equals(""))
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Category is successfully added.', 'Success');", true);
                }
                else if (hndBRANDCATEGORY_ID.Value != "")
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Category is successfully updated.', 'Success');", true);
                }
                ClearFormdata();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Category is not added. Please try again later.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ResetPageData
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            ClearFormdata();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFormdata
    private void ClearFormdata()
    {
        try
        {
            hndBRANDCATEGORY_ID.Value = "";
            txtCategory.Text = "";
            ddlBrand.SelectedValue = "";
            ddlStatus.SelectedValue = "21";
            btnSaveCategoryList.Text = "Save Category";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}