﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPanel_Admin : System.Web.UI.MasterPage
{
    #region VariableDeclare
    LoginModule obj = new LoginModule();
    #endregion
    protected void Page_Init(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] == null)
            {
                string returnUrl = HttpContext.Current.Request.Url.AbsoluteUri; // Get the current URL
                Session["ReturnUrl"] = returnUrl; // Save it to Session
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('error', 'Your session has expired. Please log in again to continue.', 'Session Expired', '../UserLogin.aspx','1000');", true);
            }
            else
            {
                if (Session["Role"] != null && Session["Role"].ToString().Equals("User"))
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('error', 'Access Denied. You are not access to this page', 'Access Denied', '../UserPanel/Dashboard.aspx','1000');", true);
                }
            }
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                GetUserDetailsForAutoLogin(Session["EmpEmail"].ToString());
            }
        }
    }
    #region GetUserDetailsForAutoLogin
    public void GetUserDetailsForAutoLogin(string EmailId)
    {
        try
        {
            DataSet ds = obj.GetUserDetailsForAutoLogin(EmailId);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblTitle.Text = ds.Tables[0].Rows[0]["TITLE"].ToString();
                lblUserName.Text = ds.Tables[0].Rows[0]["Employee_Name"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region LogoutUser
    protected void lnlLogout_Click(object sender, EventArgs e)
    {
        try
        {
            ClearSession();
            RedirectToLoginPage();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearSession
    private void ClearSession()
    {
        try
        {
            // Clear specific session variables if needed
            Session.Remove("EmpCode");
            Session.Remove("EmployeeName");
            Session.Remove("EmpEmail");
            Session.Remove("Title");
            Session.Remove("DeptCode");

            // Abandon the current session
            Session.Clear();
            Session.Abandon();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region RedirectToLoginPage
    private void RedirectToLoginPage()
    {
        try
        {
            // Redirect to the login page or any other desired destination
            ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('error', 'You have successfully logged out. Thank you for using the portal!', 'Logout Successful', '../UserLogin.aspx','1000');", true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}
