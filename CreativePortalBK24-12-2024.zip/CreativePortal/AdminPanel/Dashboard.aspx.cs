﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPanel_Dashboard : System.Web.UI.Page
{
    #region VariableDeclare
    CreativeClass obj = new CreativeClass();
    protected string ReceiveRequest;
    protected string PendingRequest;
    protected string CompleteRequest;
    protected string RejectRequest;
    protected string DesignSubmit;
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmpCode"] != null)
        {
            if (!IsPostBack)
            {
                GetAdminDashboardData();
            }
        }
    }
    #region GetAdminDashboardData
    private void GetAdminDashboardData()
    {
        try
        {
            DataSet ds = obj.GetAdminDashboardData(Session["EmpCode"].ToString(), Session["EmployeeName"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                ReceiveRequest = ds.Tables[0].Rows[0]["TotalRequest"].ToString();
                PendingRequest = ds.Tables[0].Rows[1]["TotalRequest"].ToString();
                CompleteRequest = ds.Tables[0].Rows[2]["TotalRequest"].ToString();
                RejectRequest = ds.Tables[0].Rows[3]["TotalRequest"].ToString();
                DesignSubmit = ds.Tables[0].Rows[4]["TotalRequest"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}