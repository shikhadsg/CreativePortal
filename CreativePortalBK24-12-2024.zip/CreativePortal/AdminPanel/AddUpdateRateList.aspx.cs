﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Oracle.ManagedDataAccess.Client;

public partial class PolicyRequest_AddUpdateRateList : System.Web.UI.Page
{
    #region DeclareVariable 
    CreativeClass obj = new CreativeClass();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmpCode"] != null)
        {
            if (!IsPostBack)
            {
                GetRateList();
            }
        }
    }
    #region GetRateList
    protected void GetRateList()
    {
        try
        {
            DataSet ds = obj.GetRateList(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                GrdRateList.DataSource = ds;
                GrdRateList.DataBind();
            }
            else
            {
                GrdRateList.DataSource = ds.Tables[0];
                GrdRateList.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region UpdateRateList
    protected void GrdRateList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if(e.CommandName.Equals("EditRateList"))
            {
                hndCRM_RECID.Value = e.CommandArgument.ToString();
                DataSet ds = obj.GetRateList(Session["EmpCode"].ToString(), hndCRM_RECID.Value);
                if (ds.Tables[1].Rows.Count > 0)
                {
                    txtItemName.Text = ds.Tables[1].Rows[0]["ITEM_NAME"].ToString();
                    txtRate.Text = ds.Tables[1].Rows[0]["RATE"].ToString();
                    ddlStatus.SelectedValue = ds.Tables[1].Rows[0]["StatusId"].ToString();
                    btnSaveRateList.Text = "Update Rate";
                    btnSaveRateList.Focus();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearFormdata
    private void ClearFormdata()
    {
        try
        {
            hndCRM_RECID.Value = "";
            txtItemName.Text = "";
            txtRate.Text = "";
            ddlStatus.SelectedValue = "A";
            btnSaveRateList.Text = "Save Rate";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region RestPageControll
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            ClearFormdata();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SaveRateList
    protected void btnSaveRateList_Click(object sender, EventArgs e)
    {
        int success = 0;
        string currdate = Convert.ToDateTime(DateTime.Now).ToString("dd/MM/yyyy HH:mm:ss");
        try
        {
            success = obj.AddUpdateRate(Session["EmpCode"].ToString(), hndCRM_RECID.Value, HttpUtility.HtmlEncode(txtItemName.Text.Trim()), HttpUtility.HtmlEncode(txtRate.Text.Trim()), ddlStatus.SelectedValue, currdate);
            if (success > 0)
            {
                GetRateList();
                if (hndCRM_RECID.Value.Equals(""))
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Rate is successfully added.', 'Success');", true);
                }
                else if (hndCRM_RECID.Value != "")
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Rate is successfully updated.', 'Success');", true);
                }
                ClearFormdata();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Rate is not added. Please try again later.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}