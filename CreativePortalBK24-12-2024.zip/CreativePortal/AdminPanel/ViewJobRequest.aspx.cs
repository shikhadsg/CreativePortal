﻿using System;
using System.Data;
using System.Web;
using System.Drawing;
using System.IO;
using System.Web.Configuration;
using System.Web.UI;
using Microsoft.Office.Interop.Excel;
using System.Web.UI.WebControls;
using System.IdentityModel.Protocols.WSTrust;


public partial class UserPanel_ViewJobRequest : System.Web.UI.Page
{
    #region DeclareVariable 
    JobRequest obj = new JobRequest();
    MailUtility objm = new MailUtility();
    string Url = "https://webportal.dsgroup.com/CREPortal/";
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpCode"] != null)
            {
                txtNewDeadline.Attributes["min"] = DateTime.Now.ToString("yyyy-MM-dd");
                txtRemark.Attributes.Add("maxlength", txtRemark.MaxLength.ToString());
                txtAdditionalComment.Attributes.Add("maxlength", txtRemark.MaxLength.ToString());
                if (Request.QueryString["ReqId"] != null)
                {
                    hndReqId.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["ReqId"].ToString()));
                    GetAssignToUser();
                    GetJobRequestDetails();
                }
            }
        }
    }
    #region GetAssignToUser
    private void GetAssignToUser()
    {
        try
        {
            DataSet ds = obj.GetAssignToUser(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlAssignTo.DataSource = ds.Tables[0];
                ddlAssignTo.DataTextField = "Employee_Name";
                ddlAssignTo.DataValueField = "EMAIL_ID";
                ddlAssignTo.DataBind();
                ddlAssignTo.Items.Insert(0, new ListItem("--Select Assign To--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetJobRequestDetails
    private void GetJobRequestDetails()
    {
        try
        {
            DataSet ds = obj.GetJobRequestDetails(Session["EmpCode"].ToString(), hndReqId.Value);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow jobDetails = ds.Tables[0].Rows[0];

                ConfigureButtonsAndFields(jobDetails);
                PopulateJobDetails(jobDetails);
                ConfigureAttachments(jobDetails);
                LoadAdditionalData(ds);
            }
        }
        catch (Exception ex)
        {
            // Log the exception before rethrowing
            throw ex;
        }
    }

    private void ConfigureButtonsAndFields(DataRow jobDetails)
    {
        string formatStatus = jobDetails["FORMAT_STATUS"].ToString();
        string assignToEmail = jobDetails["ASSIGN_TO_EMAIL"].ToString();
        string sessionEmail = Session["EmpEmail"].ToString();

        bool isCurrentUserAssigned = assignToEmail.Equals(sessionEmail);

        btnTransferJobRequest.Visible = (formatStatus == "U" && isCurrentUserAssigned);
        btnAcceptRejectJobRequest.Visible = btnTransferJobRequest.Visible;

        lblAssignTo.Visible = !btnTransferJobRequest.Visible;
        ddlAssignTo.Visible = btnTransferJobRequest.Visible;

        lblNewDeadline.Visible = !btnTransferJobRequest.Visible;
        txtNewDeadline.Visible = btnTransferJobRequest.Visible;

        if (btnTransferJobRequest.Visible)
        {
            ddlAssignTo.SelectedItem.Text = jobDetails["ASSIGN_TO"].ToString();
            //txtNewDeadline.Text = jobDetails["TARGET_DATE"].ToString();
        }
        else
        {
            lblAssignTo.Text = jobDetails["ASSIGN_TO"].ToString();
            lblNewDeadline.Text = jobDetails["TARGET_DATE"].ToString();
        }

        bool canSaveRemarks = (formatStatus == "P" || formatStatus == "S") && isCurrentUserAssigned;
        btnSaveRemarks.Visible = canSaveRemarks;
        btnDesignSubmitted.Visible = canSaveRemarks;
        UserRemarks.Visible = canSaveRemarks;

        txtDesignSubmittedFilePath.Visible = (formatStatus == "P" && isCurrentUserAssigned);
    }

    private void PopulateJobDetails(DataRow jobDetails)
    {
        lblRequestNo.Text = jobDetails["REQUEST_NO"].ToString();
        lblJobRequestType.Text = jobDetails["ATT2"].ToString();
        lblPriority.Text = jobDetails["PRIORITYNAME"].ToString();
        lblBrand.Text = jobDetails["BRAND_NAME"].ToString();
        lblCategory.Text = jobDetails["BRANDCATEGORY_NAME"].ToString();
        lblVarient.Text = jobDetails["BRANDVARIANT_NAME"].ToString();
        lblSKU.Text = jobDetails["SKU"].ToString();
        txtOtherBrand.Text = jobDetails["BRAND_OTHER"].ToString();
        lblType.Text = jobDetails["TYPENAME"].ToString();
        lblSubType.Text = jobDetails["CRE_SUBTYPE"].ToString();
        lblOtherType.Text = jobDetails["CRE_TYPE_OTHER"].ToString();
        lblLANGUAGE.Text = jobDetails["P_LANGUAGE"].ToString();
        lblEntryDt.Text = jobDetails["ENTRY_DATE"].ToString();
        lblTargetDate.Text = jobDetails["TARGET_DATE"].ToString();
        lblMatter.Text = HttpUtility.HtmlDecode(jobDetails["P_SUBSTRATE"].ToString());
        lblUserRemarks.Text = HttpUtility.HtmlDecode(jobDetails["USER_REMARK"].ToString());
        lblArtworkFormat.Text = jobDetails["P_FORMAT"].ToString();
        lblOtherArtworkFormat.Text = jobDetails["FORMAT_OTHER"].ToString();

        hndCreaterName.Value = jobDetails["Employee_Name"].ToString();
        hndCreaterEmail.Value = jobDetails["Creater_Email"].ToString();
        lblJobRequestStatus.Text = jobDetails["FORMAT_STATUS_DESC"].ToString();

        //lblHead.Text = jobDetails["Head"].ToString();
        //lblBasis.Text = jobDetails["Basis"].ToString();
        //lblSubHead.Text = jobDetails["Sub_Head"].ToString();
        //lblRate.Text = jobDetails["Rate"].ToString();

        DataSet dsToCcMail = obj.GetToCcMail(Session["EmpCode"].ToString(), jobDetails["REQUEST_NO"].ToString());
        if (dsToCcMail.Tables[0].Rows.Count > 0)
        {
            lblToMail.Text = dsToCcMail.Tables[0].Rows[0]["Mail_To"].ToString();
            lblCcMail.Text = dsToCcMail.Tables[0].Rows[0]["Mail_Cc"].ToString();
        }
    }

    private void ConfigureAttachments(DataRow jobDetails)
    {
        ConfigureHyperLink(hlSFTPFilePath, jobDetails["SFTP_PATH"].ToString(), "../Docs/");
        ConfigureHyperLink(hlAttachedFile, jobDetails["MEDIA_FILE_PATH"].ToString(), "../Docs/");

        string finalDesignPath = jobDetails["FINALDESIGNPATH"].ToString();
        hlDesignFinalPath.Visible = true;
        ConfigureHyperLink(hlDesignFinalPath, finalDesignPath, string.Empty);

        lblRateCard.Text = jobDetails["Rate_Card"].ToString();
        lblPageRate.Text = jobDetails["Page_Rate"].ToString();
    }

    private void ConfigureHyperLink(HyperLink link, string path, string basePath)
    {
        if (path.Equals("Na", StringComparison.OrdinalIgnoreCase))
        {
            link.Enabled = false;
            link.ForeColor = Color.Red;
            link.ToolTip = "Attached file not available.";
            link.NavigateUrl = "#";
            link.Text = "NA";
        }
        else
        {
            link.Enabled = true;
            link.ForeColor = Color.Green;
            link.ToolTip = "Click here to view attached file.";
            link.NavigateUrl = basePath + path;
            link.Text = path;
            link.Target = "_blank";
        }
    }

    private void LoadAdditionalData(DataSet ds)
    {
        BindGrid(grdFileList, ds.Tables[1]);
        BindGrid(grdRemarks, ds.Tables[2]);
    }

    private void BindGrid(GridView grid, System.Data.DataTable table)
    {
        grid.DataSource = table;
        grid.DataBind();
    }
    #endregion
    #region SaveRemarksAndFile
    protected void btnSaveRemarks_Click(object sender, EventArgs e)
    {
        int success = 0;
        string FileName = string.Empty;
        string FolderPath = string.Empty;
        string currdate = Convert.ToDateTime(DateTime.Now).ToString("dd/MM/yyyy HH:mm:ss");
        try
        {
            if (flupload.HasFile)
            {
                string FileExt = Path.GetExtension(flupload.FileName);
                decimal FileSize = Math.Round(((decimal)flupload.PostedFile.ContentLength / (decimal)1024), 2);
                if (FileExt.Equals(".jpeg") || FileExt.Equals(".jpg") || FileExt.Equals(".png") || FileExt.Equals(".pdf"))
                {
                    if (FileSize <= 10000)
                    {
                        FolderPath = Server.MapPath(WebConfigurationManager.AppSettings["JobRequestFile"]);
                        FileName = Path.GetFileNameWithoutExtension(flupload.PostedFile.FileName) + "_" + DateTime.Now.ToString("yyyy-dd-M--HH-mm-ss") + FileExt;
                        if (!Directory.Exists(FolderPath))
                        {
                            Directory.CreateDirectory(FolderPath);
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'The file size exceeds 10 MB. Kindly resubmit the document with a file size not exceeding 5 MB', 'Error');", true);
                        return;
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'we need you to upload documents in either pdf,jpeg,jpg and png file formats only', 'Error');", true);
                    return;
                }
            }
            success = obj.SaveRemarksAndFile(Session["EmpCode"].ToString(), hndReqId.Value, lblRequestNo.Text, HttpUtility.HtmlEncode(txtRemark.Text.Trim()), FileName, currdate);
            if (success > 0)
            {
                if (FileName.Length > 5)
                {
                    flupload.PostedFile.SaveAs(FolderPath + "\\" + FileName);
                }
                string Subject = "Remarks/Comments for Document No. " + lblRequestNo.Text;
                string Body = "You have received the following remarks/comments regarding Document No. " + lblRequestNo.Text;
                Url = Url + "UserPanel/ViewJobRequest.aspx?ReqId=" + CommonUtility.Encryption(hndReqId.Value);
                objm.SendMailForAction(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(), hndCreaterEmail.Value, hndCreaterName.Value, Subject, Body, txtRemark.Text.Trim(), Url);
                txtRemark.Text = "";
                GetJobRequestDetails();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showSuccessToast", "showToast('success', 'Remark is successfully added.', 'Success');", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Remark is not added. Please try again later.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region OpenPopupForAcceptRejectJobRequest
    protected void btnAcceptRejectJobRequest_Click(object sender, EventArgs e)
    {
        try
        {
            ActionNotificationBox.Show();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region RejectJobRequest
    protected void btnRejectRequest_Click(object sender, EventArgs e)
    {
        int success = 0;
        string currdate = Convert.ToDateTime(DateTime.Now).ToString("dd/MM/yyyy HH:mm:ss");
        string Remark = "Job Request Rejected. " + HttpUtility.HtmlEncode(txtAdditionalComment.Text.Trim());
        try
        {
            success = obj.AcceptRejectjobRequest(Session["EmpCode"].ToString(),hndReqId.Value,"R", "", Remark, "Rejected", currdate, lblRequestNo.Text, "");
            if (success > 0)
            {
                string Subject = "Creative Design Job Request Document No. " + lblRequestNo.Text;
                string Body = "We’re pleased to inform you that your request for a Creative Design job has been rejected by " + Session["Title"].ToString() + " " + Session["EmployeeName"].ToString() + ". Please take a moment to review the details of the request at your earliest convenience.";
                Url = Url + "UserPanel/ViewJobRequest.aspx?ReqId=" + CommonUtility.Encryption(hndReqId.Value);
                if (!string.IsNullOrEmpty(hndCreaterEmail.Value))
                {
                    objm.SendMailForAction(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(), hndCreaterEmail.Value, hndCreaterName.Value, Subject, Body, "", Url);
                }
                GetJobRequestDetails();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'Job Request is Rejected successfully.', 'Success', 'Dashboard.aspx','1000');", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Job Request is not Rejected. Please try again later.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region AcceptjobRequest
    protected void btnApprovedRequest_Click(object sender, EventArgs e)
    {
        int success = 0;
        string currdate = Convert.ToDateTime(DateTime.Now).ToString("dd/MM/yyyy HH:mm:ss");
        string Remark = "Job Request Accepted. " + HttpUtility.HtmlEncode(txtAdditionalComment.Text.Trim());
        DateTime targetDate;
        DateTime newDeadline;
        string NewDeadlineDate = string.Empty;
        string Body = string.Empty;
        try
        {
            if (!string.IsNullOrEmpty(txtNewDeadline.Text.Trim()))
            {
                if (DateTime.TryParse(lblTargetDate.Text, out targetDate) &&
                DateTime.TryParse(txtNewDeadline.Text.Trim(), out newDeadline))
                {
                    if (targetDate == newDeadline)
                    {
                        NewDeadlineDate = "";
                    }
                    else
                    {
                        NewDeadlineDate = txtNewDeadline.Text.Trim();
                    }
                }
            }
            success = obj.AcceptRejectjobRequest(Session["EmpCode"].ToString(), hndReqId.Value, "P", "" , Remark, "Accepted", currdate, lblRequestNo.Text, NewDeadlineDate);
            if (success > 0)
            {
                string Subject = "Creative Design Job Request Document No. " + lblRequestNo.Text;
                if (!string.IsNullOrEmpty(txtNewDeadline.Text.Trim()))
                {
                    Body = "We’re pleased to inform you that your request for a Creative Design job has been accepted by " + Session["Title"].ToString() + " " + Session["EmployeeName"].ToString() + " . Additionally, the new deadline has been set for <b>" + txtNewDeadline.Text.Trim() + "</b> Please take a moment to review the details of the request at your earliest convenience.";
                }
                else
                {
                    Body = "We’re pleased to inform you that your request for a Creative Design job has been accepted by " + Session["Title"].ToString() + " " + Session["EmployeeName"].ToString() + ". Please take a moment to review the details of the request at your earliest convenience.";
                }
                Url = Url + "UserPanel/ViewJobRequest.aspx?ReqId=" + CommonUtility.Encryption(hndReqId.Value);
                if (!string.IsNullOrEmpty(hndCreaterEmail.Value))
                {
                    objm.SendMailForAction(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(), hndCreaterEmail.Value, hndCreaterName.Value, Subject, Body, "", Url);
                }
                GetJobRequestDetails();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect",
                    "showToastAndRedirect('success', 'Job Request is Accepted successfully.', 'Success', 'ViewJobRequest.aspx?ReqId=" + Request.QueryString["ReqId"].ToString() + "', '1000');", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Job Request is not Accepted. Please try again later.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region TransferJobRequest
    protected void btnTransferJobRequest_Click(object sender, EventArgs e)
    {
        int success = 0;
        string currdate = Convert.ToDateTime(DateTime.Now).ToString("dd/MM/yyyy HH:mm:ss");
        try
        {
            string Remarks = Session["Title"].ToString() + " " + Session["EmployeeName"].ToString() + " has transferred the job request to " + ddlAssignTo.SelectedItem.Text;
            success = obj.TransferjobRequest(Session["EmpCode"].ToString(), hndReqId.Value, ddlAssignTo.SelectedValue ,ddlAssignTo.SelectedItem.Text, "U", Remarks, currdate, lblRequestNo.Text);
            if (success > 0)
            {
                string Subject = "Job Request Transferred Document No. " + lblRequestNo.Text;
                string Body = "This is to inform you that the job request initially assigned to " + Session["Title"].ToString() + " " + Session["EmployeeName"].ToString() + " has now been successfully transferred to " + ddlAssignTo.SelectedItem.Text + ". Please feel free to reach out if you have any questions or need further clarification regarding this change.";
                Url = Url + "UserPanel/ViewJobRequest.aspx?ReqId=" + CommonUtility.Encryption(hndReqId.Value);
                if (!string.IsNullOrEmpty(hndCreaterEmail.Value))
                {
                    objm.SendMailForJobRequest(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(), hndCreaterEmail.Value, hndCreaterName.Value, ddlAssignTo.SelectedValue ,Subject, Body, "", Url);
                }
                GetJobRequestDetails();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'Job Request has transferred successfully.', 'Success', 'Dashboard.aspx','1000');", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Job Request has not has transferred. Please try again later.', 'Error');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region DesignSubmitted
    protected void btnDesignSubmitted_Click(object sender, EventArgs e)
    {
        int success = 0;
        string currdate = Convert.ToDateTime(DateTime.Now).ToString("dd/MM/yyyy HH:mm:ss");
        string Remark = "Job Request Design submitted. " + HttpUtility.HtmlEncode(txtAdditionalComment.Text.Trim());
        try
        {
            // Validate Group1
            Page.Validate("DesignSubmitted");
            bool isGroup1Valid = Page.IsValid;

            // Validate Group2
            Page.Validate("AddRemarks");
            bool isGroup2Valid = Page.IsValid;
            if (isGroup1Valid && isGroup2Valid)
            {
                success = obj.AcceptRejectjobRequest(Session["EmpCode"].ToString(), hndReqId.Value, "S", txtDesignSubmittedFilePath.Text.Trim(), Remark, "Design Submitted", currdate, lblRequestNo.Text,"");
                if (success > 0)
                {
                    string Subject = "Creative Design Job Request Document No. " + lblRequestNo.Text;
                    string Body = "We’re pleased to inform you that your request for a Creative Design job has been submitted by " + Session["Title"].ToString() + " " + Session["EmployeeName"].ToString() + ". Please take a moment to review the details of the request at your earliest convenience.";
                    Url = Url + "UserPanel/ViewJobRequest.aspx?ReqId=" + CommonUtility.Encryption(hndReqId.Value);
                    if (!string.IsNullOrEmpty(hndCreaterEmail.Value))
                    {
                        objm.SendMailForAction(Session["EmpEmail"].ToString(), Session["EmployeeName"].ToString(), hndCreaterEmail.Value, hndCreaterName.Value, Subject, Body, "", Url);
                    }
                    GetJobRequestDetails();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect",
                        "showToastAndRedirect('success', 'Job Request Creative Design is submitted successfully.', 'Success', 'ViewJobRequest.aspx?ReqId=" + Request.QueryString["ReqId"].ToString() + "', '1000');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Job Request Creative Design is  not submitted. Please try again later.', 'Error');", true);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}