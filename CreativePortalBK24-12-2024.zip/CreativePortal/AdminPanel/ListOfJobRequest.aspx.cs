﻿using Microsoft.Office.Interop.Excel;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPanel_ListOfJobRequest : System.Web.UI.Page
{
    #region DeclareVariable 
    CreativeClass obj = new CreativeClass();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmpCode"] != null)
        {
            if (!IsPostBack)
            {
                GetBrandList();
                GetAssignToUser();
                GetMonthlyReport();
                ddlAssignTo.SelectedValue = Session["EmpEmail"].ToString();
            }
        }
    }
    #region GetBrandList
    private void GetBrandList()
    {
        try
        {
            DataSet ds = obj.GetBrandList(Session["EmpCode"].ToString());
            if (ds.Tables[2].Rows.Count > 0)
            {
                ddlBrand.DataSource = ds.Tables[2];
                ddlBrand.DataTextField = "BRAND_NAME";
                ddlBrand.DataValueField = "BRAND_ID";
                ddlBrand.DataBind();
                ddlBrand.Items.Insert(0, new ListItem("--Select Brand--", ""));
                ddlBrand.Items.Insert(24, new ListItem("Other", "24"));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetAssignToUser
    private void GetAssignToUser()
    {
        try
        {
            DataSet ds = obj.GetAssignToUser(Session["EmpCode"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlAssignTo.DataSource = ds.Tables[0];
                ddlAssignTo.DataTextField = "Employee_Name";
                ddlAssignTo.DataValueField = "EMAIL_ID";
                ddlAssignTo.DataBind();
                ddlAssignTo.Items.Insert(0, new ListItem("--Select Assign To--", ""));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetMonthlyReport
    protected void GetMonthlyReport()
    {
        try
        {
            DataSet ds = obj.GetMonthlyReport(Session["EmpCode"].ToString(), hndWhereCondition.Value);
            if (ds.Tables[0].Rows.Count > 0)
            {
                btnExport.Visible = true;
                gvData.DataSource = ds.Tables[0];
                gvData.DataBind();
            }
            else
            {
                btnExport.Visible = false;
                gvData.DataSource = ds.Tables[0];
                gvData.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SearchRecord
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        hndWhereCondition.Value = string.Empty;
        try
        {
            if (ddlPriority.SelectedIndex > 0)
            {
                hndWhereCondition.Value += " and PRIORITY = '" + ddlPriority.SelectedValue + "' ";
            }
            if (txtRequestNo.Text.Trim() != "")
            {
                hndWhereCondition.Value += " and REQUEST_NO = '" + txtRequestNo.Text.Trim() + "' ";
            }
            if (ddlBrand.SelectedIndex > 0)
            {
                hndWhereCondition.Value += " and BRAND = '" + ddlBrand.SelectedValue + "' ";
            }
            if (txtEntryDt.Text != "")
            {
                hndWhereCondition.Value += " and A.CREATED_ON >= TO_DATE('" + txtEntryDt.Text + "', 'YYYY-MM-DD') ";
            }
            if (txtEntryDtTo.Text != "")
            {
                hndWhereCondition.Value += " and A.CREATED_ON <= TO_DATE('" + txtEntryDtTo.Text + "', 'YYYY-MM-DD') ";
            }
            //if (txtTargetDt.Text != "")
            //{
            //    hndWhereCondition.Value += " and A.TARGET_DATE = TO_DATE('" + txtTargetDt.Text + "', 'YYYY-MM-DD') ";
            //}
            if (ddlAssignTo.SelectedIndex > 0)
            {
                hndWhereCondition.Value += " and ASSIGN_TO_EMAIL = '" + ddlAssignTo.SelectedValue + "' ";
            }
            hndWhereCondition.Value += " order by CREATED_ON  ";
            if (hndWhereCondition.Value != "")
            {
                GetMonthlyReport();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ResetFilterData
    protected void btnResetFilter_Click(object sender, EventArgs e)
    {
        try
        {
            txtEntryDt.Text = "";
            txtEntryDtTo.Text = "";
            hndWhereCondition.Value += "  order by CREATED_ON  ";
            GetMonthlyReport();
        }
        catch (OracleException ex)
        {
            throw ex;
        }
    }
    #endregion
    #region PageChangeCode
    protected void gvData_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvData.PageIndex = e.NewPageIndex;
            GetMonthlyReport();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportGridDataToExcel
    protected void ExportGridDataToExcel()
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=CreativeBriefFormatReport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";

            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                // To Export all pages.
                gvData.AllowPaging = false;
                this.GetMonthlyReport();
                // This is to ensure that the gridview is formatted correctly in Excel
                gvData.HeaderRow.BackColor = Color.Green;
                gvData.HeaderRow.ForeColor = Color.White;
                gvData.Columns[0].Visible = false;

                foreach (TableCell cell in gvData.HeaderRow.Cells)
                {
                    cell.BackColor = gvData.HeaderStyle.BackColor;
                    cell.Font.Size = FontUnit.Point(12);
                }

                foreach (GridViewRow row in gvData.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = Color.White;
                            cell.ForeColor = Color.Black;
                            cell.Font.Size = FontUnit.Point(10);
                        }
                        else
                        {
                            cell.BackColor = Color.White;
                            cell.ForeColor = Color.Black;
                            cell.Font.Size = FontUnit.Point(10);
                        }
                        cell.CssClass = "textmode";
                    }
                }

                gvData.RenderControl(hw);

                // Style to format numbers to string.
                string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();

                // Inject JavaScript to hide the progress bar
                ScriptManager.RegisterStartupScript(this, GetType(), "HideProgress", "HideProgessBar();", true);
            }
        }
        catch (OracleException ex)
        {
            throw ex;
        }
    }
    #endregion
    #region VerifyRenderingInServerForm
    public override void VerifyRenderingInServerForm(Control control)
    {
        /*Tell the compiler that the control is rendered
         * explicitly by overriding the VerifyRenderingInServerForm event.*/
    }
    #endregion
    #region ExportDataToExcel
    protected void btnExcel_Click(object sender, EventArgs e)
    {
        try
        {
            ExportGridDataToExcel();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}