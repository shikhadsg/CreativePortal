﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using System.IO;
using System.Drawing;
using ClosedXML.Excel;

public partial class PolicyRequest_MonthlyReport : System.Web.UI.Page
{
    #region DeclareVariable 
    CreativeClass obj = new CreativeClass();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmpCode"] != null)
        {
            if (!IsPostBack)
            {
                ddlAssignTo.SelectedValue = Session["EmployeeName"].ToString();
                txtEntryDt.Attributes["max"] = DateTime.Now.ToString("yyyy-MM-dd");
                txtEntryDtTo.Attributes["max"] = DateTime.Now.ToString("yyyy-MM-dd");
                GetBrandList();
                GetMonthlyReport();
            }
        }
    }
    #region GetBrandList
    private void GetBrandList()
    {
        try
        {
            DataSet ds = obj.GetBrandList(Session["EmpCode"].ToString());
            if (ds.Tables[2].Rows.Count > 0)
            {
                ddlBrand.DataSource = ds.Tables[2];
                ddlBrand.DataTextField = "BRAND_NAME";
                ddlBrand.DataValueField = "BRAND_ID";
                ddlBrand.DataBind();
                ddlBrand.Items.Insert(0, new ListItem("--Select Brand--", ""));
                ddlBrand.Items.Insert(24, new ListItem("Other", "24"));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region GetMonthlyReport
    protected void GetMonthlyReport()
    {
        try
        {
            DataSet ds = obj.GetMonthlyReport(Session["EmpCode"].ToString(), hndWhereCondition.Value);
            if (ds.Tables[0].Rows.Count > 0)
            {
                btnExport.Visible = true;
                gvData.DataSource = ds.Tables[0];
                gvData.DataBind();
            }
            else
            {
                btnExport.Visible = false;
                gvData.DataSource = ds.Tables[0];
                gvData.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportGriddataToExcel
    protected void btnExport_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dt = new DataTable();

            // Add columns based on GridView BoundField headers
            foreach (DataControlField column in gvData.Columns)
            {
                if (column is BoundField)
                {
                    dt.Columns.Add(((BoundField)column).HeaderText);
                }
            }

            // Add rows from GridView
            foreach (GridViewRow row in gvData.Rows)
            {
                DataRow dr = dt.NewRow();
                for (int i = 0; i < row.Cells.Count; i++)
                {
                    dr[i] = row.Cells[i].Text;
                }
                dt.Rows.Add(dr);
            }

            // Create and export Excel file using ClosedXML
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt, "GridView Data");
                Response.Clear();
                Response.Buffer = true;
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.AddHeader("content-disposition", "attachment;filename=MonthlyReport.xlsx");

                using (var memoryStream = new System.IO.MemoryStream())
                {
                    wb.SaveAs(memoryStream);
                    memoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ResetFilterData
    protected void btnResetFilter_Click(object sender, EventArgs e)
    {
        try
        {
            txtEntryDt.Text = "";
            txtEntryDtTo.Text = "";
            hndWhereCondition.Value += "  order by CREATED_ON  ";
            GetMonthlyReport();
        }
        catch (OracleException ex)
        {
            throw ex;
        }
    }
    #endregion
    #region SerchRecord
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        hndWhereCondition.Value = string.Empty;
        try
        {
            if (ddlBrand.SelectedIndex > 0)
            {
                hndWhereCondition.Value += " and BRAND = '" + ddlBrand.SelectedValue + "' ";
            }
            if (ddlAssignTo.SelectedIndex > 0)
            {
                hndWhereCondition.Value += " and ASSIGN_TO = '" + ddlAssignTo.SelectedValue + "' ";
            }
            if (txtEntryDt.Text != "")
            {
                hndWhereCondition.Value += " and A.CREATED_ON >= TO_DATE('" + txtEntryDt.Text + "', 'YYYY-MM-DD') ";
            }
            if (txtEntryDtTo.Text != "")
            {
                hndWhereCondition.Value += " and A.CREATED_ON <= TO_DATE('" + txtEntryDtTo.Text + "', 'YYYY-MM-DD') ";
            }
            if (ddlAssignTo.SelectedIndex > 0)
            {
                hndWhereCondition.Value += " and ASSIGN_TO = '" + ddlAssignTo.SelectedValue + "' ";
            }
            hndWhereCondition.Value += " order by CREATED_ON  ";
            if (hndWhereCondition.Value != "")
            {
                GetMonthlyReport();
            }
        }
        catch (OracleException ex)
        {
            throw ex;
        }
    }
    #endregion
}