﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserPanel_ListOfJobRequestStatus : System.Web.UI.Page
{
    #region DeclareVariable 
    CreativeClass obj = new CreativeClass();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmpCode"] != null)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["StatusId"] != null)
                {
                    hndStatusId.Value = CommonUtility.Decryption(HttpUtility.UrlDecode(Request.QueryString["StatusId"].ToString()));
                    GetMonthlyReport();
                }
            }
        }
    }
    #region GetMonthlyReport
    protected void GetMonthlyReport()
    {
        try
        {
            DataSet ds = obj.GetMonthlyReport(Session["EmployeeName"].ToString(), "" ,hndStatusId.Value);
            if (ds.Tables[1].Rows.Count > 0)
            {
                btnExport.Visible = true;
                gvData.DataSource = ds.Tables[1];
                gvData.DataBind();
            }
            else
            {
                btnExport.Visible = false;
                gvData.DataSource = ds.Tables[1];
                gvData.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region PageChangeCode
    protected void gvData_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvData.PageIndex = e.NewPageIndex;
            GetMonthlyReport();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ExportGridDataToExcel
    protected void ExportGridDataToExcel()
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=CreativeBriefFormatReport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";

            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                // To Export all pages.
                gvData.AllowPaging = false;
                this.GetMonthlyReport();
                // This is to ensure that the gridview is formatted correctly in Excel
                gvData.HeaderRow.BackColor = Color.Green;
                gvData.HeaderRow.ForeColor = Color.White;
                gvData.Columns[0].Visible = false;

                foreach (TableCell cell in gvData.HeaderRow.Cells)
                {
                    cell.BackColor = gvData.HeaderStyle.BackColor;
                    cell.Font.Size = FontUnit.Point(12);
                }

                foreach (GridViewRow row in gvData.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = Color.White;
                            cell.ForeColor = Color.Black;
                            cell.Font.Size = FontUnit.Point(10);
                        }
                        else
                        {
                            cell.BackColor = Color.White;
                            cell.ForeColor = Color.Black;
                            cell.Font.Size = FontUnit.Point(10);
                        }
                        cell.CssClass = "textmode";
                    }
                }

                gvData.RenderControl(hw);

                // Style to format numbers to string.
                string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        catch (OracleException ex)
        {
            throw ex;
        }
    }
    #endregion
    #region VerifyRenderingInServerForm
    public override void VerifyRenderingInServerForm(Control control)
    {
        /*Tell the compiler that the control is rendered
         * explicitly by overriding the VerifyRenderingInServerForm event.*/
    }
    #endregion
    #region ExportDataToExcel
    protected void btnExcel_Click(object sender, EventArgs e)
    {
        try
        {
            ExportGridDataToExcel();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}