﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Configuration;
using System.Data;

/// <summary>
/// Summary description for ConnectionCode
/// </summary>
internal class ConnectionCode
{
    public string strCon; // Public variable to hold connection string
    /// <summary>
    /// Class Constructor to initialize ElekhaConnect class instance.
    /// </summary>
    public ConnectionCode()
    {
        strCon = ConfigurationManager.ConnectionStrings["CreativePortal"].ConnectionString;
    }
    /// <summary>
    /// Obtains Data Base Connection
    /// </summary>
    /// <returns>An opened SqlConnection object</returns>
    public OracleConnection getConnection()
    {
        OracleConnection dbCon = null;
        try
        {
            dbCon = new OracleConnection(strCon);
            dbCon.Open();
        }
        catch (Exception ex)
        {
            if (dbCon.State != ConnectionState.Open)
            {
                throw new Exception("ConOpenFail");
            }
            throw ex;
        }
        return dbCon;
    }

    /// <summary>
    /// Close DataBase Connection
    /// </summary>
    /// <param name="con">An SqlConnection object</param>
    /// <returns>True, if connection is closed; False, if connection is not closed</returns>
    public bool returnConnection(OracleConnection con)
    {
        if (con != null)
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
            if (con.State == ConnectionState.Closed)
            {
                con = null;
                return true;
            }
            else
                return false;
        }
        else
            return true;
    }
    public void CloseConnection(OracleConnection con)
    {
        if (con != null)
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
            if (con.State == ConnectionState.Closed)
            {
                con = null;
            }
        }
    }
}