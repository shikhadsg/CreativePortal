﻿using Oracle.ManagedDataAccess.Client;
using Org.BouncyCastle.Asn1.Cmp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CreativeClass
/// </summary>
public class CreativeClass
{
    #region Variable Declaration
    OracleConnection con;
    ConnectionCode sCon;
    OracleCommand cmd;
    #endregion
    #region GetAssignToUser
    public DataSet GetAssignToUser(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select EMAIL_ID,initcap(Employee_Name)Employee_Name from hrm_employee 
                                    where EMAIL_ID in ('prachi.grover@dsgroup.com','husain.saeed@dsgroup.com','balam.singh@dsgroup.com','arshad.hussain@dsgroup.com',
                                    'chetan.kushwaha@dsgroup.com') and STATUS in ('C','P','N') order by Employee_Name";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetAdminDashboardData
    public DataSet GetAdminDashboardData(string EmpCode, string EmployeeName)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select count(*)TotalRequest from CRE_FORMAT_D where ASSIGN_TO = '" + EmployeeName + "' and FORMAT_STATUS = 'U' " +
                        "union all select count(*)RequestProcessed from CRE_FORMAT_D where ASSIGN_TO = '" + EmployeeName + "' and FORMAT_STATUS = 'P' " +
                        "union all select count(*)CompleteProcessed from CRE_FORMAT_D where ASSIGN_TO = '" + EmployeeName + "' and FORMAT_STATUS = 'F' " +
                        "union all  select count(*)RejectProcessed from CRE_FORMAT_D where ASSIGN_TO = '" + EmployeeName + "' and FORMAT_STATUS = 'R'" +
                        "union all  select count(*)RejectProcessed from CRE_FORMAT_D where ASSIGN_TO = '" + EmployeeName + "' and FORMAT_STATUS = 'S'";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetBrandList
    public DataSet GetBrandList(string EmpCode, string BrandId = "0")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select BRAND_ID,BRAND_NAME,b.CREATED_BY,b.CREATED_ON,b.LAST_UPD_BY,b.LAST_UPD_ON,initcap(e.Employee_Name)CreaterName,nvl(initcap(e1.Employee_Name),'-')UpdatedName,
                                    case when STATUS_ID = 21 then 'Active' else 'In-Active' end Status,b.STATUS_ID
                                    from Brand_List b
                                    left join hrm_employee e on e.Emp_Code = b.CREATED_BY
                                    left join hrm_employee e1 on e1.Emp_Code = b.LAST_UPD_BY
                                    order by BRAND_NAME";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"select BRAND_ID,BRAND_NAME,CREATED_BY,CREATED_ON,(STATUS_ID)StatusId,case when STATUS_ID = 21 then 'Active' else 'In-Active' end Status from Brand_List where BRAND_ID = '" + BrandId + "'";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    // Query 3 with parameter
                    string query3 = @"select BRAND_ID,INITCAP(BRAND_NAME)BRAND_NAME from Brand_List where STATUS_ID = 21 order by BRAND_NAME";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region AddUpdateBrand
    public int AddUpdateBrand(string EmpCode, string BrandId, string Brand, string Status, string currdate)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    if (BrandId == "")
                    {
                        cmd.CommandText = "insert into Brand_List (BRAND_ID,BRAND_NAME,STATUS_ID,CREATED_BY,CREATED_ON)" +
                        " values (portal_recid.nextval,'" + Brand + "','" + Status + "','" + EmpCode + "',to_date('" + currdate + "','dd/MM/yyyy hh24:mi:ss'))";
                    }
                    else if (BrandId != "")
                    {
                        cmd.CommandText = @"update Brand_List set BRAND_NAME = '" + Brand + "',STATUS_ID = '" + Status + "',LAST_UPD_BY = '" + EmpCode + "',LAST_UPD_ON = to_date('" + currdate + "','dd/MM/yyyy hh24:mi:ss') where BRAND_ID = '" + BrandId + "'";
                    }
                    cmd.CommandType = CommandType.Text;
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region GetCategoryList
    public DataSet GetCategoryList(string EmpCode, string BrandCategoryId = "0")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select bc.BRAND_ID,BRAND_NAME,bc.BRANDCATEGORY_ID,BRANDCATEGORY_NAME,nvl(BRANDVARIANT_NAME,'-')BRANDVARIANT_NAME,
                                    bc.CREATED_BY,bc.STATUS_ID,bc.CREATED_ON,bc.LAST_UPD_BY,bc.LAST_UPD_ON,initcap(e.Employee_Name)CreaterName,nvl(initcap(e1.Employee_Name),'-')UpdatedName,
                                    case when bc.STATUS_ID = 21 then 'Active' else 'In-Active' end Status,bc.STATUS_ID
                                    from Brand_Category bc
                                    left join Brand_List bl on bl.BRAND_ID = bc.BRAND_ID
                                    left join Brand_Variant bv on bv.BRANDCATEGORY_ID = bc.BRANDCATEGORY_ID
                                    left join hrm_employee e on e.Emp_Code = bc.CREATED_BY
                                    left join hrm_employee e1 on e1.Emp_Code = bc.LAST_UPD_BY
                                    order by BRAND_NAME,BRANDCATEGORY_NAME,BRANDVARIANT_NAME";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"select bl.BRAND_ID,BRAND_NAME,BRANDCATEGORY_ID,BRANDCATEGORY_NAME,bc.CREATED_BY,bc.STATUS_ID,bc.CREATED_ON,case when bc.STATUS_ID = 21 then 'Active' else 'In-Active' end Status from Brand_Category bc left join Brand_List bl on bl.BRAND_ID = bc.BRAND_ID where BRANDCATEGORY_ID = '" + BrandCategoryId + "'";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region AddUpdateCategory
    public int AddUpdateCategory(string EmpCode, string CategoryId ,string BrandId, string Category, string Status, string currdate)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    if (CategoryId == "")
                    {
                        cmd.CommandText = "insert into Brand_Category (BRANDCATEGORY_ID,BRAND_ID,BRANDCATEGORY_NAME,STATUS_ID,CREATED_BY,CREATED_ON)" +
                        " values (portal_recid.nextval,'" + BrandId + "','" + Category + "','" + Status + "','" + EmpCode + "',to_date('" + currdate + "','dd/MM/yyyy hh24:mi:ss'))";
                    }
                    else if (CategoryId != "")
                    {
                        cmd.CommandText = @"update Brand_Category set BRAND_ID = '" + BrandId + "',BRANDCATEGORY_NAME = '" + Category + "',STATUS_ID = '" + Status + "',LAST_UPD_BY = '" + EmpCode + "',LAST_UPD_ON = to_date('" + currdate + "','dd/MM/yyyy hh24:mi:ss') where BRANDCATEGORY_ID = '" + CategoryId + "'";
                    }
                    cmd.CommandType = CommandType.Text;
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region GetRateList
    public DataSet GetRateList(string EmpCode, string RecId = "0")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select CRM_RECID,ITEM_NAME,RATE,case when m.STATUS = 'A' then 'Active' when m.STATUS = 'I' then 'In-Active' end Status,
                                    m.CREATED_ON,m.LAST_UPD_BY,m.LAST_UPD_ON,initcap(e.Employee_Name)CreaterName,nvl(initcap(e1.Employee_Name),'-')UpdatedName
                                    from CRE_RATECARD_M m
                                    left join hrm_employee e on e.Emp_Code = m.CREATED_BY
                                    left join hrm_employee e1 on e1.Emp_Code = m.LAST_UPD_BY
                                    order by CREATED_ON desc";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"select CRM_RECID,ITEM_NAME,RATE,CREATED_BY,CREATED_ON,(STATUS)StatusId,case when STATUS = 'A' then 'Active' when STATUS = 'I' then 'In-Active' end Status from CRE_RATECARD_M where CRM_RECID = '" + RecId + "'";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region AddUpdateRate
    public int AddUpdateRate(string EmpCode, string RecId, string Item, string Rate, string Status, string currdate)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    if (RecId == "")
                    {
                        cmd.CommandText = "insert into CRE_RATECARD_M (CRM_RECID,ITEM_NAME,RATE,STATUS,CREATED_BY,CREATED_ON)" +
                        " values (portal_recid.nextval,'" + Item + "','" + Rate + "','" + Status + "','" + EmpCode + "',to_date('" + currdate + "','dd/MM/yyyy hh24:mi:ss'))";
                    }
                    else if (RecId != "")
                    {
                        cmd.CommandText = @"update CRE_RATECARD_M set ITEM_NAME = '" + Item + "',RATE = '" + Rate + "',STATUS = '" + Status + "',LAST_UPD_BY = '" + EmpCode + "',LAST_UPD_ON = to_date('" + currdate + "','dd/MM/yyyy hh24:mi:ss') where CRM_RECID = '" + RecId + "'";
                    }
                    cmd.CommandType = CommandType.Text;
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region GetMonthlyReport
    public DataSet GetMonthlyReport(string EmpCode, string WhereCondition = "", string FormStatus = "")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"SELECT ROW_NUMBER() OVER (ORDER BY A.CREATED_ON) AS SrNo,(select EMPLOYEE_NAME from hrm_employee where EMP_CODE = a.CREATED_BY)Initiator,ROUND((TRUNC(SYSDATE) - A.CREATED_ON)) AS NoOfDays,
                         CHANGESREQUIREDYESNO,a.CFD_RECID,REQUEST_NO,A.STATUS,case when PRIORITY = 'N' then 'Normal' else 'Urgent' end PriorityName,PRIORITY,A.CREATED_BY,A.CREATED_ON,
                         BRAND,BRAND_NAME,BRAND_OTHER,nvl(SKU,'-')SKU,VARIANT,nvl(BRANDVARIANT_NAME,'-')BRANDVARIANT_NAME,CRE_TYPE,CRE_SUBTYPE,CRE_TYPE_OTHER,P_LANGUAGE,ENTRY_DATE,TARGET_DATE,P_SUBSTRATE,USER_REMARK,
                         P_FORMAT,FORMAT_OTHER,ASSIGN_TO,SFTP_PATH,MEDIA_FILE_PATH,COALESCE(NEW_TIMELINE, TO_DATE(TARGET_DATE, 'YYYY-MM-DD')) AS NEW_TIMELINE,nvl(a.ATT1,'-')ATT1,nvl(a.ATT2,'-')ATT2,
                         ATT4,ATT5,ATT6,FORMAT_STATUS,(SELECT DISPLAY_VALUE FROM FD_LOOKUP_VALUES_M M WHERE LOOKUP_TYPE = 'CREATIVE_ST' AND M.LOOKUP_CD = A.FORMAT_STATUS)
                         AS FORMAT_STATUS_desc,(select max(CREATED_ON) from PKG_JW_SPEC_REMARKS where ARTWORK_NUMBER = A.CFD_RECID)MaxDate,NVL(TO_CHAR(r.RATE), '-')RATE,
                         Feedback_Text,Rating
                         FROM CRE_FORMAT_d A
                         left join Brand_List bl on bl.BRAND_ID = A.BRAND
                         left join Brand_Variant bv on bv.BRANDVARIANT_ID = A.VARIANT
                         left join CRE_RATECARD_M r on r.CRM_RECID = a.RATE_ID
                         left join Cre_Feedback f on f.CFD_RECID = a.CFD_RECID
                         WHERE A.STATUS = 'A' " + WhereCondition +  " ";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"SELECT ROW_NUMBER() OVER (ORDER BY A.CREATED_ON) AS SrNo,(select EMPLOYEE_NAME from hrm_employee where EMP_CODE = a.CREATED_BY)Initiator,ROUND((TRUNC(SYSDATE) - A.CREATED_ON)) AS NoOfDays,
                         CHANGESREQUIREDYESNO,a.CFD_RECID,REQUEST_NO,A.STATUS,case when PRIORITY = 'N' then 'Normal' else 'Urgent' end PriorityName,PRIORITY,A.CREATED_BY,A.CREATED_ON,
                         BRAND,BRAND_NAME,BRAND_OTHER,nvl(SKU,'-')SKU,VARIANT,nvl(BRANDVARIANT_NAME,'-')BRANDVARIANT_NAME,CRE_TYPE,CRE_SUBTYPE,CRE_TYPE_OTHER,P_LANGUAGE,ENTRY_DATE,TARGET_DATE,P_SUBSTRATE,USER_REMARK,
                         P_FORMAT,FORMAT_OTHER,ASSIGN_TO,SFTP_PATH,MEDIA_FILE_PATH,COALESCE(NEW_TIMELINE, TO_DATE(TARGET_DATE, 'YYYY-MM-DD')) AS NEW_TIMELINE,nvl(a.ATT1,'-')ATT1,nvl(a.ATT2,'-')ATT2,
                         ATT4,ATT5,ATT6,FORMAT_STATUS,(SELECT DISPLAY_VALUE FROM FD_LOOKUP_VALUES_M M WHERE LOOKUP_TYPE = 'CREATIVE_ST' AND M.LOOKUP_CD = A.FORMAT_STATUS)
                         AS FORMAT_STATUS_desc,(select max(CREATED_ON) from PKG_JW_SPEC_REMARKS where ARTWORK_NUMBER = A.CFD_RECID)MaxDate,NVL(TO_CHAR(r.RATE), '-')RATE,
                         Feedback_Text,Rating
                         FROM CRE_FORMAT_d A
                         left join Brand_List bl on bl.BRAND_ID = A.BRAND
                         left join Brand_Variant bv on bv.BRANDVARIANT_ID = A.VARIANT
                         left join CRE_RATECARD_M r on r.CRM_RECID = a.RATE_ID
                         left join Cre_Feedback f on f.CFD_RECID = a.CFD_RECID
                         WHERE A.ASSIGN_TO = '" + EmpCode + "' and A.FORMAT_STATUS = '" + FormStatus + "' order by CFD_RECID desc";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetRateMasterList
    public DataSet GetRateMasterList(string EmpCode, string RateId = "0")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select Rate_Id,Head,Basis,Sub_Head,Rate,case when m.STATUS = 'A' then 'Active' when m.STATUS = 'I' then 'In-Active' end Status,
                                    m.CREATED_ON,m.Updated_By,m.Updated_On,initcap(e.Employee_Name)CreaterName,nvl(initcap(e1.Employee_Name),'-')UpdatedName,(m.STATUS)Status_Id
                                    from Cre_Rate_Master m
                                    left join hrm_employee e on e.Emp_Code = m.CREATED_BY
                                    left join hrm_employee e1 on e1.Emp_Code = m.Updated_By
                                    order by Head,Basis,Sub_Head";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"select Rate_Id,Head,Basis,Sub_Head,Rate,CREATED_BY,CREATED_ON,(STATUS)StatusId,case when STATUS = 'A' then 'Active' when STATUS = 'I' then 'In-Active' end Status from Cre_Rate_Master where Rate_Id = '" + RateId + "'";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region AddUpdateRateMaster
    public int AddUpdateRateMaster(string EmpCode, string RateId, string Head, string Basis, string SubHead, string Rate, string Status)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    if (RateId == "")
                    {
                        cmd.CommandText = "insert into Cre_Rate_Master (Rate_Id,Head,Basis,Sub_Head,Rate,STATUS,CREATED_BY,CREATED_ON)" +
                        " values (portal_recid.nextval,'" + Head + "','" + Basis + "','" + SubHead + "','" + Rate + "','" + Status + "','" + EmpCode + "', sysdate)";
                    }
                    else if (RateId != "")
                    {
                        cmd.CommandText = @"update Cre_Rate_Master set Head = '" + Head + "',Basis = '" + Basis + "',Sub_Head = '" + SubHead + "',RATE = '" + Rate + "',STATUS = '" + Status + "',UPDATED_BY = '" + EmpCode + "',UPDATED_ON = sysdate where Rate_Id = '" + RateId + "'";
                    }
                    cmd.CommandType = CommandType.Text;
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
}