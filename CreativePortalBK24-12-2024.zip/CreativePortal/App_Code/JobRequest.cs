﻿using Oracle.ManagedDataAccess.Client;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for JobRequest
/// </summary>
public class JobRequest
{
    #region Variable Declaration
    OracleConnection con;
    ConnectionCode sCon;
    OracleCommand cmd;
    #endregion
    #region GetUserDashboardData
    public DataSet GetUserDashboardData(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select count(*)TotalRequest from CRE_FORMAT_D where CREATED_BY = '" + EmpCode + "' and FORMAT_STATUS = 'U' " +
                        "union all select count(*)RequestProcessed from CRE_FORMAT_D where CREATED_BY = '" + EmpCode + "' and FORMAT_STATUS = 'P' " +
                        "union all select count(*)CompleteProcessed from CRE_FORMAT_D where CREATED_BY = '" + EmpCode + "' and FORMAT_STATUS = 'F' " +
                        "union all  select count(*)RejectProcessed from CRE_FORMAT_D where CREATED_BY = '" + EmpCode + "' and FORMAT_STATUS = 'R'" +
                        "union all  select count(*)RejectProcessed from CRE_FORMAT_D where CREATED_BY = '" + EmpCode + "' and FORMAT_STATUS = 'S'";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetRequestNo
    public DataSet GetRequestNo(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select lpad( nvl( max(substr(REQUEST_NO,INSTR(REQUEST_NO, '-', -1)+1)+1),1),4,'0')RequestNo from CRE_FORMAT_D";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetAssignToUser
    public DataSet GetAssignToUser(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select EMAIL_ID,initcap(Employee_Name)Employee_Name from hrm_employee 
                                    where EMAIL_ID in ('prachi.grover@dsgroup.com','husain.saeed@dsgroup.com','balam.singh@dsgroup.com','arshad.hussain@dsgroup.com',
                                    'chetan.kushwaha@dsgroup.com') and STATUS in ('C','P','N')
                                    and Emp_Code not in ('" + EmpCode + "') order by Employee_Name";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetMaxRequestId
    public DataSet GetMaxRequestId(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select max(CFD_RECID)MaxRequestId from CRE_FORMAT_D";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetJobRequestDetails
    public DataSet GetJobRequestDetails(string EmpCode, string RecId)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"SELECT CFD_RECID,REQUEST_NO,A.STATUS,case when PRIORITY = 'N' then 'Normal' else 'Urgent' end PriorityName,PRIORITY,initcap(e.Employee_Name)Employee_Name,(e.Email_id)Creater_Email,
                                        A.CREATED_BY,A.CREATED_ON,BRAND,BRAND_NAME,nvl(BRAND_OTHER,'-')BRAND_OTHER,nvl(SKU,'-')SKU,VARIANT,nvl(BRANDVARIANT_NAME,'-')BRANDVARIANT_NAME,CRE_TYPE,(MEANING)TypeName,
                                        CRE_SUBTYPE,nvl(CRE_TYPE_OTHER,'-')CRE_TYPE_OTHER,nvl(P_LANGUAGE,'-')P_LANGUAGE,ENTRY_DATE,TARGET_DATE,P_SUBSTRATE,USER_REMARK,P_FORMAT,
                                        nvl(FORMAT_OTHER,'-')FORMAT_OTHER,ASSIGN_TO,nvl(SFTP_PATH,'Na')SFTP_PATH,nvl(MEDIA_FILE_PATH,'Na')MEDIA_FILE_PATH,NEW_TIMELINE,A.LAST_UPD_ON,A.LAST_UPD_BY,nvl(a.ATT1,'_')Page_Rate,a.ATT2,ATT4,ATT5,
                                        ATT6,FORMAT_STATUS,RATE_ID,a.RATE,(SELECT DISPLAY_VALUE FROM FD_LOOKUP_VALUES_M M WHERE LOOKUP_TYPE = 'CREATIVE_ST' AND M.LOOKUP_CD = A.FORMAT_STATUS) AS FORMAT_STATUS_desc,
                                        CATEGORY,BRANDCATEGORY_NAME,PACKAGING,BRANDPACKAGING_NAME,CHANGESREQUIREDYESNO,
                                        (ITEM_NAME)Rate_Card,nvl(FinalDesignPath,'Na')FinalDesignPath,ASSIGN_TO_EMAIL
                                        FROM CRE_FORMAT_d A
                                        left join Brand_List bl on bl.BRAND_ID = A.BRAND
                                        left join Brand_Variant bv on bv.BRANDVARIANT_ID = A.VARIANT
                                        left join vw_hrm_employee e on e.Emp_Code = A.CREATED_BY
                                        left join FD_LOOKUP_TYPES_M t on  t.LOOKUP_TYPE_ID = A.CRE_TYPE
                                        left join Brand_Category Bc on  bc.BRANDCATEGORY_ID = A.CATEGORY
                                        left join Brand_Packaging Bp on  bp.BRANDPACKAGING_ID = A.PACKAGING
                                        left join CRE_RATECARD_M r on r.CRM_RECID = a.RATE_ID
                                        WHERE A.CFD_RECID = '" + RecId + "' ";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"select CRE_FILE_ID,CFD_RECID,('~/Docs/' || FILENAME)FILENAME,(select EMPLOYEE_NAME from hrm_employee where EMP_CODE = a.CREATED_BY)CREATED_BY,CREATED_ON 
                                    from cre_file a where CFD_RECID = '" + RecId + "' order by CRE_FILE_ID desc";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    // Query 3 with parameter
                    string query3 = @"select JSR_RECID,ARTWORK_NUMBER,REF_ARTWORK_NUMBER,(select EMPLOYEE_NAME from hrm_employee where EMP_CODE = a.CREATED_BY)CREATED_BY,CREATED_ON,JOB_DESC,STATUS_DESC,APP_REF 
                                    from PKG_JW_SPEC_REMARKS a where ARTWORK_NUMBER ='" + RecId + "' order by JSR_RECID desc";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);

                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetToCcMail
    public DataSet GetToCcMail(string EmpCode, string RequestNo)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select RecId,REQUEST_NO,Mail_To,Mail_Cc from CRE_MAIL_TO_CC where REQUEST_NO = '" + RequestNo + "' ";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetJobRequestData
    public DataSet GetJobRequestData(string EmpCode)
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"select distinct DESCRIPTION from hrm_Department where Status = 'A'  order by DESCRIPTION";
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                    {
                        da.Fill(ds);
                        objTrans.Commit();
                    }
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
            // throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetMasterDataList
    public DataSet GetMasterDataList(string EmpCode, string RecId = "0")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select BRAND_ID,INITCAP(BRAND_NAME)BRAND_NAME from Brand_List where STATUS_ID = 21 order by BRAND_NAME";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"SELECT M.LOOKUP_TYPE_ID,M.LOOKUP_TYPE,INITCAP(MEANING)MEANING
                                     FROM  FD_LOOKUP_TYPES_M  M
                                     WHERE LOOKUP_TYPE_ID IN (540,541,542,543,544,545,546,828,829)  AND M.STATUS= 'A'
                                     ORDER BY LOOKUP_TYPE_ID";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    // Query 3 with parameter
                    string query3 = @"select BRANDCATEGORY_ID,INITCAP(BRANDCATEGORY_NAME)BRANDCATEGORY_NAME from Brand_Category where BRAND_ID = '" + RecId + "' and STATUS_ID = 21 order by BRANDCATEGORY_NAME";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);

                    // Query 4 with parameter
                    string query4 = @"select BRANDVARIANT_ID,INITCAP(BRANDVARIANT_NAME)BRANDVARIANT_NAME from Brand_Variant where BRANDCATEGORY_ID = '" + RecId + "' and STATUS_ID = 21 order by BRANDVARIANT_NAME";
                    OracleDataAdapter adapter4 = new OracleDataAdapter(query4, con);
                    adapter4.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable4 = new DataTable("Table4");
                    adapter4.Fill(dataTable4);
                    ds.Tables.Add(dataTable4);

                    // Query 5 with parameter
                    string query5 = @"SELECT M.LOOKUP_TYPE_ID,M.LOOKUP_TYPE,MEANING,LOOKUP_VALUE_ID,LOOKUP_CD,INITCAP(DISPLAY_VALUE)DISPLAY_VALUE
                                    FROM  FD_LOOKUP_TYPES_M  M, FD_LOOKUP_VALUES_M V 
                                    WHERE LOOKUP_TYPE_ID IN ("+ RecId + ") AND V.LOOKUP_TYPE =M.LOOKUP_TYPE AND M.STATUS= 'A' AND V.STATUS= 'A'  ORDER BY LOOKUP_TYPE_ID , LOOKUP_VALUE_ID ";
                    OracleDataAdapter adapter5 = new OracleDataAdapter(query5, con);
                    adapter5.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable5 = new DataTable("Table5");
                    adapter5.Fill(dataTable5);
                    ds.Tables.Add(dataTable5);

                    // Query 6 with parameter
                    string query6 = @"select Email_Id,EMP_CODE,initcap(EMPLOYEE_NAME || ' (' || EMP_CODE || ')')EMPLOYEE_NAME 
                                    from Hrm_Employee 
                                    where STATUS in ('C','P','N') and DEPT_CODE = 'MKT' and CD_CODE in ('M3','M2','M0','D') order by EMPLOYEE_NAME";
                    OracleDataAdapter adapter6 = new OracleDataAdapter(query6, con);
                    adapter6.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable6 = new DataTable("Table6");
                    adapter6.Fill(dataTable6);
                    ds.Tables.Add(dataTable6);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetRateMasterList
    public DataSet GetRateMasterList(string EmpCode, string Flag = "")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"select distinct HEAD from Cre_Rate_Master where Status = 'A' order by Head";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"select distinct BASIS from Cre_Rate_Master where Status = 'A' and Head = '" + Flag + "' order by BASIS";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);

                    // Query 3 with parameter
                    string query3 = @"select distinct SUB_HEAD from Cre_Rate_Master where Status = 'A' and BASIS = '" + Flag + "' order by SUB_HEAD";
                    OracleDataAdapter adapter3 = new OracleDataAdapter(query3, con);
                    adapter3.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable3 = new DataTable("Table3");
                    adapter3.Fill(dataTable3);
                    ds.Tables.Add(dataTable3);

                    // Query 4 with parameter
                    string query4 = @"select distinct RATE from Cre_Rate_Master where Status = 'A' and SUB_HEAD = '" + Flag + "' order by Rate";
                    OracleDataAdapter adapter4 = new OracleDataAdapter(query4, con);
                    adapter4.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable4 = new DataTable("Table4");
                    adapter4.Fill(dataTable4);
                    ds.Tables.Add(dataTable4);

                    //// Query 5 with parameter
                    //string query5 = @"SELECT M.LOOKUP_TYPE_ID,M.LOOKUP_TYPE,MEANING,LOOKUP_VALUE_ID,LOOKUP_CD,INITCAP(DISPLAY_VALUE)DISPLAY_VALUE
                    //                FROM  FD_LOOKUP_TYPES_M  M, FD_LOOKUP_VALUES_M V 
                    //                WHERE LOOKUP_TYPE_ID IN (" + RecId + ") AND V.LOOKUP_TYPE =M.LOOKUP_TYPE AND M.STATUS= 'A' AND V.STATUS= 'A'  ORDER BY LOOKUP_TYPE_ID , LOOKUP_VALUE_ID ";
                    //OracleDataAdapter adapter5 = new OracleDataAdapter(query5, con);
                    //adapter5.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    //DataTable dataTable5 = new DataTable("Table5");
                    //adapter5.Fill(dataTable5);
                    //ds.Tables.Add(dataTable5);

                    //// Query 6 with parameter
                    //string query6 = @"select Email_Id,EMP_CODE,initcap(EMPLOYEE_NAME || ' (' || Dept_Code || ')')EMPLOYEE_NAME from Hrm_Employee where STATUS in ('C','P','N') and DEPT_CODE = 'MKT' order by EMPLOYEE_NAME";
                    //OracleDataAdapter adapter6 = new OracleDataAdapter(query6, con);
                    //adapter6.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    //DataTable dataTable6 = new DataTable("Table6");
                    //adapter6.Fill(dataTable6);
                    //ds.Tables.Add(dataTable6);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region GetJobRequestList
    public DataSet GetJobRequestList(string EmpCode, string WhereCondition = "", string FormStatus = "")
    {
        DataSet ds = new DataSet();
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    // Query 1 with parameter
                    string query1 = @"SELECT ROW_NUMBER() OVER (ORDER BY A.CREATED_ON) AS SrNo,(select EMPLOYEE_NAME from hrm_employee where EMP_CODE = a.CREATED_BY)Initiator,ROUND((TRUNC(SYSDATE) - A.CREATED_ON)) AS NoOfDays,
                         CHANGESREQUIREDYESNO,a.CFD_RECID,REQUEST_NO,A.STATUS,case when PRIORITY = 'N' then 'Normal' else 'Urgent' end PriorityName,PRIORITY,A.CREATED_BY,A.CREATED_ON,
                         BRAND,BRAND_NAME,BRAND_OTHER,nvl(SKU,'-')SKU,VARIANT,nvl(BRANDVARIANT_NAME,'-')BRANDVARIANT_NAME,CRE_TYPE,CRE_SUBTYPE,CRE_TYPE_OTHER,P_LANGUAGE,ENTRY_DATE,TARGET_DATE,P_SUBSTRATE,USER_REMARK,
                         P_FORMAT,FORMAT_OTHER,ASSIGN_TO,SFTP_PATH,MEDIA_FILE_PATH,COALESCE(NEW_TIMELINE, TO_DATE(TARGET_DATE, 'YYYY-MM-DD')) AS NEW_TIMELINE,nvl(a.ATT1,'-')ATT1,nvl(a.ATT2,'-')ATT2,
                         ATT4,ATT5,ATT6,FORMAT_STATUS,(SELECT DISPLAY_VALUE FROM FD_LOOKUP_VALUES_M M WHERE LOOKUP_TYPE = 'CREATIVE_ST' AND M.LOOKUP_CD = A.FORMAT_STATUS)
                         AS FORMAT_STATUS_desc,(select max(CREATED_ON) from PKG_JW_SPEC_REMARKS where ARTWORK_NUMBER = A.CFD_RECID)MaxDate,NVL(TO_CHAR(r.RATE), '-')RATE,
                         Feedback_Text,Rating
                         FROM CRE_FORMAT_d A
                         left join Brand_List bl on bl.BRAND_ID = A.BRAND
                         left join Brand_Variant bv on bv.BRANDVARIANT_ID = A.VARIANT
                         left join CRE_RATECARD_M r on r.CRM_RECID = a.RATE_ID
                         left join Cre_Feedback f on f.CFD_RECID = a.CFD_RECID
                         WHERE a.CREATED_BY = '" + EmpCode + "' " + WhereCondition + " order by CFD_RECID desc";
                    OracleDataAdapter adapter1 = new OracleDataAdapter(query1, con);
                    adapter1.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable1 = new DataTable("Table1");
                    adapter1.Fill(dataTable1);
                    ds.Tables.Add(dataTable1);

                    // Query 2 with parameter
                    string query2 = @"SELECT ROW_NUMBER() OVER (ORDER BY A.CREATED_ON) AS SrNo,(select EMPLOYEE_NAME from hrm_employee where EMP_CODE = a.CREATED_BY)Initiator,ROUND((TRUNC(SYSDATE) - A.CREATED_ON)) AS NoOfDays,
                         CHANGESREQUIREDYESNO,a.CFD_RECID,REQUEST_NO,A.STATUS,case when PRIORITY = 'N' then 'Normal' else 'Urgent' end PriorityName,PRIORITY,A.CREATED_BY,A.CREATED_ON,
                         BRAND,BRAND_NAME,BRAND_OTHER,nvl(SKU,'-')SKU,VARIANT,nvl(BRANDVARIANT_NAME,'-')BRANDVARIANT_NAME,CRE_TYPE,CRE_SUBTYPE,CRE_TYPE_OTHER,P_LANGUAGE,ENTRY_DATE,TARGET_DATE,P_SUBSTRATE,USER_REMARK,
                         P_FORMAT,FORMAT_OTHER,ASSIGN_TO,SFTP_PATH,MEDIA_FILE_PATH,COALESCE(NEW_TIMELINE, TO_DATE(TARGET_DATE, 'YYYY-MM-DD')) AS NEW_TIMELINE,nvl(a.ATT1,'-')ATT1,nvl(a.ATT2,'-')ATT2,
                         ATT4,ATT5,ATT6,FORMAT_STATUS,(SELECT DISPLAY_VALUE FROM FD_LOOKUP_VALUES_M M WHERE LOOKUP_TYPE = 'CREATIVE_ST' AND M.LOOKUP_CD = A.FORMAT_STATUS)
                         AS FORMAT_STATUS_desc,(select max(CREATED_ON) from PKG_JW_SPEC_REMARKS where ARTWORK_NUMBER = A.CFD_RECID)MaxDate,NVL(TO_CHAR(r.RATE), '-')RATE,
                         Feedback_Text,Rating
                         FROM CRE_FORMAT_d A
                         left join Brand_List bl on bl.BRAND_ID = A.BRAND
                         left join Brand_Variant bv on bv.BRANDVARIANT_ID = A.VARIANT
                         left join CRE_RATECARD_M r on r.CRM_RECID = a.RATE_ID
                         left join Cre_Feedback f on f.CFD_RECID = a.CFD_RECID
                         WHERE A.CREATED_BY = '" + EmpCode + "' and A.FORMAT_STATUS = '" + FormStatus + "' order by CFD_RECID desc";
                    OracleDataAdapter adapter2 = new OracleDataAdapter(query2, con);
                    adapter2.SelectCommand.Parameters.Add("@EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    DataTable dataTable2 = new DataTable("Table2");
                    adapter2.Fill(dataTable2);
                    ds.Tables.Add(dataTable2);
                }
            }
        }
        catch (Exception)
        {
            objTrans.Rollback();
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
    #region AddUpdateJobRequest
    public int AddUpdateJobRequest(string EmpCode, string RequestNo, string EntryDate, string JobRequestType, string Priority, string Brand, string BrandOther, string Category, string Varient,
                        string SKU, string CreType, string CreSubType, string CreOtherType, string Language, string TargetDate, string ArtworkFormat,
                        string SFTPFilePath, string OtherArtworkFormat, string Matter, string UserRemarks, string AssignToEmail, string  AssignTo,string currdate, string  FileName)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"INSERT INTO CRE_FORMAT_D (CFD_RECID,REQUEST_NO,STATUS,PRIORITY,CREATED_BY,CREATED_ON,BRAND,BRAND_OTHER,SKU,VARIANT,CRE_TYPE,
                                        CRE_SUBTYPE,CRE_TYPE_OTHER,P_LANGUAGE,ENTRY_DATE,TARGET_DATE,P_SUBSTRATE,USER_REMARK,P_FORMAT,FORMAT_OTHER,ASSIGN_TO_EMAIL,ASSIGN_TO,SFTP_PATH,
                                        MEDIA_FILE_PATH,ATT1,ATT2,ATT4,ATT5,ATT6,FORMAT_STATUS,CATEGORY)
                                        values (portal_recid.nextval,'" + RequestNo + "', 'A' ,'" + Priority + "','" + EmpCode + "',to_date('" + currdate + "','dd/MM/yyyy hh24:mi:ss')," +
                                        "'" + Brand + "', '" + BrandOther + "', '" + SKU + "', '" + Varient + "', '" + CreType + "', '" + CreSubType  + "', '" + CreOtherType + "'," +
                                        "'" + Language + "','" + EntryDate + "','" + TargetDate + "','" + Matter + "','" + UserRemarks + "','" + ArtworkFormat + "','" + OtherArtworkFormat + "'," +
                                        "'" + AssignToEmail + "','" + AssignTo + "','" + SFTPFilePath + "','" + FileName + "',null,'" + JobRequestType + "',null,null,'U','U', '" + Category + "')";
                    cmd.CommandType = CommandType.Text;
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region SaveRemarksAndFile
    public int SaveRemarksAndFile(string EmpCode, string RecId, string RequestNo, string Remarks, string FileName, string currdate)
    {
        int success = 0;
        OracleTransaction objTrans = null;

        try
        {
            // Create connection object
            sCon = new ConnectionCode();
            using (OracleConnection con = sCon.getConnection())
            {
                // Open connection only if not already open
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                // Begin transaction
                objTrans = con.BeginTransaction();

                try
                {
                    if (!string.IsNullOrEmpty(FileName))
                    {
                        // Insert into cre_file
                        using (OracleCommand cmd1 = con.CreateCommand())
                        {
                            cmd1.Transaction = objTrans;
                            cmd1.CommandText = @"INSERT INTO cre_file 
                                    (CRE_FILE_ID, CFD_RECID, FILENAME, CREATED_BY, CREATED_ON) 
                                    VALUES (portal_recid.nextval, :RecId, :FileName, :EmpCode, sysdate)";

                            cmd1.Parameters.Add("RecId", OracleDbType.Varchar2).Value = RecId;
                            cmd1.Parameters.Add("FileName", OracleDbType.Varchar2).Value = FileName;
                            cmd1.Parameters.Add("EmpCode", OracleDbType.Varchar2).Value = EmpCode;

                            success += cmd1.ExecuteNonQuery();
                        }
                    }

                    // Insert into PKG_JW_SPEC_REMARKS
                    using (OracleCommand cmd2 = con.CreateCommand())
                    {
                        cmd2.Transaction = objTrans;
                        cmd2.CommandText = @"INSERT INTO PKG_JW_SPEC_REMARKS 
                                    (JSR_RECID, ARTWORK_NUMBER, REF_ARTWORK_NUMBER, CREATED_BY, CREATED_ON, JOB_DESC, STATUS_DESC, APP_REF)
                                    VALUES (portal_recid.nextval, :RecId, :RequestNo, :EmpCode, TO_DATE(:currdate, 'dd/MM/yyyy hh24:mi:ss'), :Remarks, '', 'CRE')";

                        cmd2.Parameters.Add("RecId", OracleDbType.Varchar2).Value = RecId;
                        cmd2.Parameters.Add("RequestNo", OracleDbType.Varchar2).Value = RequestNo;
                        cmd2.Parameters.Add("EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                        cmd2.Parameters.Add("currdate", OracleDbType.Varchar2).Value = currdate;
                        cmd2.Parameters.Add("Remarks", OracleDbType.Varchar2).Value = Remarks;

                        success += cmd2.ExecuteNonQuery();
                    }

                    // Update CRE_FORMAT_D
                    using (OracleCommand cmd3 = con.CreateCommand())
                    {
                        cmd3.Transaction = objTrans;
                        cmd3.CommandText = @"UPDATE CRE_FORMAT_D 
                                     SET LAST_UPD_BY = :EmpCode, 
                                         LAST_UPD_ON = TO_DATE(:currdate, 'dd/MM/yyyy hh24:mi:ss'), 
                                         ATT5 = 'Y' 
                                     WHERE CFD_RECID = :RecId";

                        cmd3.Parameters.Add("EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                        cmd3.Parameters.Add("currdate", OracleDbType.Varchar2).Value = currdate;
                        cmd3.Parameters.Add("RecId", OracleDbType.Varchar2).Value = RecId;

                        success += cmd3.ExecuteNonQuery();
                    }

                    // Commit the transaction
                    objTrans.Commit();
                }
                catch (Exception ex)
                {
                    // Rollback transaction on failure
                    objTrans.Rollback();
                    throw new Exception("Transaction failed: " + ex.Message);
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception("Error in SaveRemarksAndFile: " + ex.Message);
        }
        finally
        {
            sCon = null; // Release connection code object
        }

        return success;
    }
    #endregion
    #region SaveMailToCc
    public int SaveMailToCc(string EmpCode, string RequestNo, string MailTo, string MailCc)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"INSERT INTO CRE_MAIL_TO_CC (RecId,REQUEST_NO,Mail_To,Mail_Cc,Created_By,Created_On)
                                        values (portal_recid.nextval,'" + RequestNo + "','" + MailTo + "', '" + MailCc + "' ,'" + EmpCode + "',sysdate)";
                    cmd.CommandType = CommandType.Text;
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region AcceptRejectjobRequest
    public int AcceptRejectjobRequest(string EmpCode, string RequestId, string Status,string DesignSubmittedFilePath, string Remarks, string RemarkStatus, string currdate, string RequestNo, string NewDeadlineDate)
    {
        int success = 0;
        OracleTransaction objTrans = null;

        try
        {
            // Create connection object
            sCon = new ConnectionCode();
            using (OracleConnection con = sCon.getConnection())
            {
                // Open connection only if not already open
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                // Begin transaction
                objTrans = con.BeginTransaction();

                try
                {
                    if (!string.IsNullOrEmpty(NewDeadlineDate) && Status.Equals("P"))
                    {
                        // Insert into cre_file
                        using (OracleCommand cmd0 = con.CreateCommand())
                        {
                            cmd0.Transaction = objTrans;
                            cmd0.CommandText = @"update CRE_FORMAT_d set NEW_TIMELINE = to_date(:NewDeadlineDate,'yyyy-MM-dd'), LAST_UPD_BY = :EmpCode,LAST_UPD_ON = sysdate where CFD_RECID = :RequestId";

                            cmd0.Parameters.Add("NewDeadlineDate", OracleDbType.Varchar2).Value = NewDeadlineDate;
                            cmd0.Parameters.Add("EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                            cmd0.Parameters.Add("RequestId", OracleDbType.Varchar2).Value = RequestId;

                            success += cmd0.ExecuteNonQuery();
                        }
                    }
                    // Update into CRE_FORMAT_d
                    using (OracleCommand cmd1 = con.CreateCommand())
                    {
                        cmd1.Transaction = objTrans;
                        cmd1.CommandText = @"update CRE_FORMAT_d set FORMAT_STATUS = :Status,FINALDESIGNPATH = :DesignSubmittedFilePath, LAST_UPD_BY = :EmpCode,LAST_UPD_ON = sysdate where CFD_RECID = :RequestId";

                        cmd1.Parameters.Add("Status", OracleDbType.Varchar2).Value = Status;
                        cmd1.Parameters.Add("DesignSubmittedFilePath", OracleDbType.Varchar2).Value = DesignSubmittedFilePath;
                        cmd1.Parameters.Add("EmpCode", OracleDbType.Varchar2).Value = EmpCode; 
                        cmd1.Parameters.Add("RequestId", OracleDbType.Varchar2).Value = RequestId;

                        success += cmd1.ExecuteNonQuery();
                    }

                    // Insert into PKG_JW_SPEC_REMARKS
                    using (OracleCommand cmd2 = con.CreateCommand())
                    {
                        cmd2.Transaction = objTrans;
                        cmd2.CommandText = @"INSERT INTO PKG_JW_SPEC_REMARKS 
                                    (JSR_RECID, ARTWORK_NUMBER, REF_ARTWORK_NUMBER, CREATED_BY, CREATED_ON, JOB_DESC, STATUS_DESC, APP_REF)
                                    VALUES (portal_recid.nextval, :RequestId, :RequestNo, :EmpCode, TO_DATE(:currdate, 'dd/MM/yyyy hh24:mi:ss'), :Remarks, :RemarkStatus, 'CRE')";

                        cmd2.Parameters.Add("RequestId", OracleDbType.Varchar2).Value = RequestId;
                        cmd2.Parameters.Add("RequestNo", OracleDbType.Varchar2).Value = RequestNo;
                        cmd2.Parameters.Add("EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                        cmd2.Parameters.Add("currdate", OracleDbType.Varchar2).Value = currdate;
                        cmd2.Parameters.Add("Remarks", OracleDbType.Varchar2).Value = Remarks;
                        cmd2.Parameters.Add("RemarkStatus", OracleDbType.Varchar2).Value = RemarkStatus;

                        success += cmd2.ExecuteNonQuery();
                    }

                    // Commit the transaction
                    objTrans.Commit();
                }
                catch (Exception ex)
                {
                    // Rollback transaction on failure
                    objTrans.Rollback();
                    throw new Exception("Transaction failed: " + ex.Message);
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception("Error in SaveRemarksAndFile: " + ex.Message);
        }
        finally
        {
            sCon = null; // Release connection code object
        }

        return success;
    }
    #endregion
    #region TransferjobRequest
    public int TransferjobRequest(string EmpCode, string RequestId, string AssignToEmail,string AssignTo, string Status, string Remarks, string currdate, string RequestNo)
    {
        int success = 0;
        OracleTransaction objTrans = null;

        try
        {
            // Create connection object
            sCon = new ConnectionCode();
            using (OracleConnection con = sCon.getConnection())
            {
                // Open connection only if not already open
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                // Begin transaction
                objTrans = con.BeginTransaction();

                try
                {
                    // Update into CRE_FORMAT_d
                    using (OracleCommand cmd1 = con.CreateCommand())
                    {
                        cmd1.Transaction = objTrans;
                        cmd1.CommandText = @"UPDATE CRE_FORMAT_d 
                                             SET ASSIGN_TO_EMAIL = :AssignToEmail,
                                                 ASSIGN_TO = :AssignTo, 
                                                 FORMAT_STATUS = :Status, 
                                                 LAST_UPD_BY = :EmpCode,  
                                                 LAST_UPD_ON = TO_DATE(:currdate, 'dd/MM/yyyy hh24:mi:ss')  
                                             WHERE CFD_RECID = :RequestId";

                        cmd1.Parameters.Add("AssignToEmail", OracleDbType.Varchar2).Value = AssignToEmail;
                        cmd1.Parameters.Add("AssignTo", OracleDbType.Varchar2).Value = AssignTo;
                        cmd1.Parameters.Add("Status", OracleDbType.Varchar2).Value = Status;
                        cmd1.Parameters.Add("EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                        cmd1.Parameters.Add("currdate", OracleDbType.Varchar2).Value = currdate;
                        cmd1.Parameters.Add("RequestId", OracleDbType.Varchar2).Value = RequestId;

                        success += cmd1.ExecuteNonQuery();
                    }

                    // Insert into PKG_JW_SPEC_REMARKS
                    using (OracleCommand cmd2 = con.CreateCommand())
                    {
                        cmd2.Transaction = objTrans;
                        cmd2.CommandText = @"INSERT INTO PKG_JW_SPEC_REMARKS 
                                    (JSR_RECID, ARTWORK_NUMBER, REF_ARTWORK_NUMBER, CREATED_BY, CREATED_ON, JOB_DESC, STATUS_DESC, APP_REF)
                                    VALUES (portal_recid.nextval, :RequestId, :RequestNo, :EmpCode, TO_DATE(:currdate, 'dd/MM/yyyy hh24:mi:ss'), :Remarks, 'Job Request Transferred', 'CRE')";

                        cmd2.Parameters.Add("RequestId", OracleDbType.Varchar2).Value = RequestId;
                        cmd2.Parameters.Add("RequestNo", OracleDbType.Varchar2).Value = RequestNo;
                        cmd2.Parameters.Add("EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                        cmd2.Parameters.Add("currdate", OracleDbType.Varchar2).Value = currdate;
                        cmd2.Parameters.Add("Remarks", OracleDbType.Varchar2).Value = Remarks;

                        success += cmd2.ExecuteNonQuery();
                    }

                    // Commit the transaction
                    objTrans.Commit();
                }
                catch (Exception ex)
                {
                    // Rollback transaction on failure
                    objTrans.Rollback();
                    throw new Exception("Transaction failed: " + ex.Message);
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception("Error in SaveRemarksAndFile: " + ex.Message);
        }
        finally
        {
            sCon = null; // Release connection code object
        }

        return success;
    }
    #endregion
    #region AddFeedback
    public int AddFeedback(string EmpCode, string CfdRecId, string Feedback, string Rating)
    {
        int success = 0;
        OracleTransaction objTrans = null;
        try
        {
            sCon = new ConnectionCode();
            con = new OracleConnection();
            cmd = new OracleCommand();
            using (con = sCon.getConnection())
            {
                objTrans = con.BeginTransaction();
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = @"INSERT INTO Cre_Feedback (Feedback_Id,CFD_RECID,Feedback_Text,Rating,Created_By,Created_On)
                                        values (portal_recid.nextval,:CfdRecId,:Feedback, :Rating ,:EmpCode,sysdate)";

                    cmd.Parameters.Add("CfdRecId", OracleDbType.Varchar2).Value = CfdRecId;
                    cmd.Parameters.Add("Feedback", OracleDbType.Varchar2).Value = Feedback;
                    cmd.Parameters.Add("Rating", OracleDbType.Varchar2).Value = Rating;
                    cmd.Parameters.Add("EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                    cmd.CommandType = CommandType.Text;
                    success = cmd.ExecuteNonQuery();
                    objTrans.Commit();
                }
            }
        }
        catch (Exception ex)
        {
            objTrans.Rollback();
            throw ex;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return success;
    }
    #endregion
    #region DesignAccept
    public int DesignAccept(string EmpCode, string RequestId, string Status, string Remarks, string RemarkStatus, string currdate, string RequestNo)
    {
        int success = 0;
        OracleTransaction objTrans = null;

        try
        {
            // Create connection object
            sCon = new ConnectionCode();
            using (OracleConnection con = sCon.getConnection())
            {
                // Open connection only if not already open
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                // Begin transaction
                objTrans = con.BeginTransaction();

                try
                {
                    // Update into CRE_FORMAT_d
                    using (OracleCommand cmd1 = con.CreateCommand())
                    {
                        cmd1.Transaction = objTrans;
                        cmd1.CommandText = @"update CRE_FORMAT_d set FORMAT_STATUS = :Status, LAST_UPD_BY = :EmpCode,LAST_UPD_ON = sysdate where CFD_RECID = :RequestId";

                        cmd1.Parameters.Add("Status", OracleDbType.Varchar2).Value = Status;
                        cmd1.Parameters.Add("EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                        cmd1.Parameters.Add("RequestId", OracleDbType.Varchar2).Value = RequestId;

                        success += cmd1.ExecuteNonQuery();
                    }

                    // Insert into PKG_JW_SPEC_REMARKS
                    using (OracleCommand cmd2 = con.CreateCommand())
                    {
                        cmd2.Transaction = objTrans;
                        cmd2.CommandText = @"INSERT INTO PKG_JW_SPEC_REMARKS 
                                    (JSR_RECID, ARTWORK_NUMBER, REF_ARTWORK_NUMBER, CREATED_BY, CREATED_ON, JOB_DESC, STATUS_DESC, APP_REF)
                                    VALUES (portal_recid.nextval, :RequestId, :RequestNo, :EmpCode, TO_DATE(:currdate, 'dd/MM/yyyy hh24:mi:ss'), :Remarks, :RemarkStatus, 'CRE')";

                        cmd2.Parameters.Add("RequestId", OracleDbType.Varchar2).Value = RequestId;
                        cmd2.Parameters.Add("RequestNo", OracleDbType.Varchar2).Value = RequestNo;
                        cmd2.Parameters.Add("EmpCode", OracleDbType.Varchar2).Value = EmpCode;
                        cmd2.Parameters.Add("currdate", OracleDbType.Varchar2).Value = currdate;
                        cmd2.Parameters.Add("Remarks", OracleDbType.Varchar2).Value = Remarks;
                        cmd2.Parameters.Add("RemarkStatus", OracleDbType.Varchar2).Value = RemarkStatus;

                        success += cmd2.ExecuteNonQuery();
                    }

                    // Commit the transaction
                    objTrans.Commit();
                }
                catch (Exception ex)
                {
                    // Rollback transaction on failure
                    objTrans.Rollback();
                    throw new Exception("Transaction failed: " + ex.Message);
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception("Error in SaveRemarksAndFile: " + ex.Message);
        }
        finally
        {
            sCon = null; // Release connection code object
        }

        return success;
    }
    #endregion
}