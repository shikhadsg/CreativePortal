﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

/// <summary>
/// Summary description for clsExcelInterface
/// </summary>
public class clsExcelInterface
{
    #region GetExcelDataTable
    public DataTable getExcelDataTable(string filePath)
    {
        DataSet result;
        using (FileStream stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
        {
            using (IExcelDataReader excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream))
            {
                result = excelReader.AsDataSet();
                excelReader.Close();
            }
        }
        return result.Tables[0];
    }
    #endregion
}